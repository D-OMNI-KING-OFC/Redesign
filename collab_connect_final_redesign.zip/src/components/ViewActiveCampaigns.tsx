// src/components/ViewActiveCampaigns.tsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabaseClient";
import styles from "./campaigns-ui.module.css";
import { t } from "../i18n/index";

type Campaign = {
  id: number;
  title: string;
  description: string | null;
  reward_per_post: number | null;
  total_slots: number;
  remaining_slots: number;
  status: string | null;
  advertiser_id: string | null; // uuid
};

type Submission = {
  id: number;
  campaign_id: number;
  creator_id: string | null; // uuid
  submission_link: string;
  status: string | null;
  submitted_at: string | null;
  revision_requested_at?: string | null;
  approved_at?: string | null;
  auto_paid?: boolean | null;
};

type DashboardProps = {
  lang: string;
};

export default function ViewActiveCampaigns({ lang }: DashboardProps): React.ReactElement {
  const navigate = useNavigate();

  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [mySubmissions, setMySubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [userUid, setUserUid] = useState<string | null>(null);
  const [participateModal, setParticipateModal] = useState<{ open: boolean; campaign?: Campaign | null }>({
    open: false,
    campaign: null,
  });
  const [submissionLink, setSubmissionLink] = useState<string>("");
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [rpcLoading, setRpcLoading] = useState<boolean>(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Added state for resubmit/reserve flow
  const [participateIsResubmit, setParticipateIsResubmit] = useState<boolean>(false);
  const [participateSubmissionId, setParticipateSubmissionId] = useState<number | null>(null);

  // Resubmit flow
  const [resubmitState, setResubmitState] = useState<{ open: boolean; submission?: Submission | null }>({
    open: false,
    submission: null,
  });
  const [resubmitLink, setResubmitLink] = useState<string>("");
  const [resubmitError, setResubmitError] = useState<string | null>(null);
  const [resubmitLoading, setResubmitLoading] = useState<boolean>(false);

  // joinedCampaigns map: campaign_id -> title
  const [joinedCampaigns, setJoinedCampaigns] = useState<Record<number, string>>({});

  // ticking clock for timers
  const [nowTs, setNowTs] = useState<number>(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNowTs(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const allowedHosts = [
    "instagram.com",
    "www.instagram.com",
    "m.instagram.com",
    "youtube.com",
    "www.youtube.com",
    "youtu.be",
    "tiktok.com",
    "www.tiktok.com",
    "twitter.com",
    "x.com",
    "www.twitter.com",
    "facebook.com",
    "www.facebook.com",
    "linkedin.com",
    "www.linkedin.com",
    "vimeo.com",
  ];

  const isValidSocialLink = (raw: string): boolean => {
    if (!raw) return false;
    const s = raw.trim();
    let url: URL | null = null;
    try {
      url = new URL(s);
    } catch {
      try {
        url = new URL("https://" + s);
      } catch {
        return false;
      }
    }
    const host = url.hostname.toLowerCase();
    if (!allowedHosts.includes(host)) return false;

    if (host.includes("youtube") || host === "youtu.be") {
      return (
        url.pathname.includes("/watch") ||
        url.pathname.includes("/shorts") ||
        host === "youtu.be" ||
        url.searchParams.get("v") !== null
      );
    }
    if (host.includes("instagram")) {
      return (
        url.pathname.includes("/p/") ||
        url.pathname.includes("/reel/") ||
        url.pathname.includes("/tv/") ||
        url.pathname.includes("/stories/")
      );
    }
    if (host.includes("tiktok")) return url.pathname.includes("/video/");
    if (host.includes("twitter") || host === "x.com") return url.pathname.includes("/status/") || url.pathname.split("/").length >= 3;
    return url.pathname && url.pathname !== "/";
  };

  // Helper: exact spelling used in your DB
  const isRevisionRequested = (status: string | null | undefined) => {
    return status === "revision requested";
  };

  // --- data fetchers ---

  // return UID so callers can use it immediately (avoids waiting for state update)
  const fetchSessionUid = async (): Promise<string | null> => {
    try {
      const { data } = await supabase.auth.getSession();
      const uid = (data as any)?.session?.user?.id ?? null;
      setUserUid(uid);
      return uid;
    } catch (err) {
      console.error("fetchSessionUid error", err);
      setUserUid(null);
      return null;
    }
  };

  // fetchCampaigns accepts optional uid so we can fetch revision campaigns immediately on first load
  const fetchCampaigns = async (uid?: string | null): Promise<void> => {
    setLoading(true);
    try {
      const effectiveUid = uid ?? userUid;

      // 1) Always fetch open campaigns (remaining_slots > 0)
      const { data: openData, error: openError } = await supabase
        .from("ad_requests")
        .select("id, title, description, reward_per_post, total_slots, remaining_slots, status, advertiser_id, created_at")
        .gt("remaining_slots", 0)
        .order("created_at", { ascending: true })
        .limit(200);

      if (openError) throw openError;

      // 2) If user is logged in, fetch campaign_ids where they have 'revision requested'
      let revisionCampaignIds: (number | string)[] = [];
      if (effectiveUid) {
        const { data: subData, error: subError } = await supabase
          .from("campaign_submissions")
          .select("campaign_id")
          .eq("creator_id", effectiveUid)
          .eq("status", "revision requested");

        if (subError) throw subError;

        revisionCampaignIds = (subData ?? []).map((r: any) => r.campaign_id).filter(Boolean);
      }

      // 3) If there are revision IDs, fetch those ad_requests rows
      let revisionCampaigns: any[] = [];
      if (revisionCampaignIds.length > 0) {
        const { data: revData, error: revError } = await supabase
          .from("ad_requests")
          .select("id, title, description, reward_per_post, total_slots, remaining_slots, status, advertiser_id, created_at")
          .in("id", revisionCampaignIds)
          .order("created_at", { ascending: true })
          .limit(200);

        if (revError) throw revError;
        revisionCampaigns = revData ?? [];
      }

      // 4) Merge results: put revision campaigns first, then open campaigns; dedupe by id
      const map = new Map<number | string, any>();

      for (const c of revisionCampaigns) {
        map.set(c.id, c);
      }
      for (const c of openData ?? []) {
        if (!map.has(c.id)) {
          map.set(c.id, c);
        }
      }

      const merged = Array.from(map.values());
      setCampaigns(merged as Campaign[]);
    } catch (err: unknown) {
      console.error("fetchCampaigns err", err);
      setCampaigns([]);
    } finally {
      setLoading(false);
    }
  };

  // fetchMySubmissions accepts optional uid so we can call immediately after reading session
  const fetchMySubmissions = async (uid?: string | null): Promise<void> => {
    try {
      const effectiveUid = uid ?? userUid;
      if (!effectiveUid) {
        setMySubmissions([]);
        setJoinedCampaigns({});
        return;
      }
      const { data, error } = await supabase
        .from<Submission>("campaign_submissions")
        .select("*")
        .eq("creator_id", effectiveUid)
        .order("submitted_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      const subs = (data as Submission[] | null) ?? [];
      setMySubmissions(subs);

      // Fetch joined campaign titles for the submissions we just fetched
      const campaignIds = Array.from(new Set(subs.map((s) => s.campaign_id))).filter(Boolean) as number[];
      await fetchJoinedCampaigns(campaignIds);
    } catch (err) {
      console.error("fetchMySubmissions err", err);
    }
  };

  const fetchJoinedCampaigns = async (ids: number[]): Promise<void> => {
    if (!ids || ids.length === 0) {
      setJoinedCampaigns({});
      return;
    }
    try {
      const { data, error } = await supabase.from<Campaign>("ad_requests").select("id,title").in("id", ids).limit(200);
      if (error) throw error;
      const map: Record<number, string> = {};
      (data ?? []).forEach((c) => {
        if (c.id) map[c.id] = c.title ?? `Campaign ${c.id}`;
      });
      setJoinedCampaigns(map);
    } catch (err) {
      console.error("fetchJoinedCampaigns err", err);
      setJoinedCampaigns({});
    }
  };

  // SINGLE initial effect: get UID, then immediately fetch campaigns + submissions.
  useEffect(() => {
    (async () => {
      const uid = await fetchSessionUid(); // sets state & returns uid
      await fetchCampaigns(uid); // immediately fetch campaigns using uid so revision-requested are included
      if (uid) await fetchMySubmissions(uid); // immediately fetch user's submissions so UI knows about revisions
    })();

    const campaignsSub = supabase
      .channel("public:ad_requests")
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "ad_requests" }, () => fetchCampaigns(userUid))
      .subscribe();

    const subsSub = supabase
      .channel("public:campaign_submissions")
      .on("postgres_changes", { event: "*", schema: "public", table: "campaign_submissions" }, () => fetchMySubmissions(userUid))
      .subscribe();

    return () => {
      supabase.removeChannel(campaignsSub);
      supabase.removeChannel(subsSub);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- participate modal controls ---

  const findRevisionSubmissionForCampaign = (campaignId: number) => {
    return mySubmissions.find((s) => s.campaign_id === campaignId && s.status === "revision requested") ?? null;
  };

  const openParticipateModal = (campaign: Campaign): void => {
    if (campaign.advertiser_id && userUid && campaign.advertiser_id === userUid) {
      setGeneralError(t("cannot_participate_own_campaign", lang));
      setTimeout(() => setGeneralError(null), 4000);
      return;
    }

    // Check if user has an existing 'revision requested' submission for this campaign
    const existing = userUid ? findRevisionSubmissionForCampaign(campaign.id) : null;

    if (existing) {
      // we're going to let the user resubmit into the same row
      setSubmissionLink(existing.submission_link ?? "");
      setParticipateIsResubmit(true);
      setParticipateSubmissionId(existing.id ?? null);
    } else {
      // normal fresh participate
      setSubmissionLink("");
      setParticipateIsResubmit(false);
      setParticipateSubmissionId(null);
    }

    setSubmissionError(null);
    setParticipateModal({ open: true, campaign });
  };

  const closeParticipateModal = (): void => {
    setParticipateModal({ open: false, campaign: null });
    setSubmissionLink("");
    setSubmissionError(null);
  };

  const handleParticipateSubmit = async (): Promise<void> => {
    setSubmissionError(null);
    setGeneralError(null);
    if (!participateModal.campaign) {
      setSubmissionError(t("campaign_context_lost", lang));
      return;
    }
    const { data: sessionData } = await supabase.auth.getSession();
    const uid = (sessionData as any)?.session?.user?.id ?? null;
    if (!uid) {
      setSubmissionError(t("must_be_signed_in", lang));
      return;
    }
    if (participateModal.campaign.advertiser_id && participateModal.campaign.advertiser_id === uid) {
      setSubmissionError(t("cannot_participate_own_campaign", lang));
      return;
    }
    const link = submissionLink.trim();
    if (!link) {
      setSubmissionError(t("paste_direct_link_prompt", lang));
      return;
    }
    if (!isValidSocialLink(link)) {
      setSubmissionError(t("invalid_link", lang));
      return;
    }

    setRpcLoading(true);
    try {
      // If this is a resubmit into an existing "revision requested" row, update that row instead.
      if (participateIsResubmit && participateSubmissionId != null) {
        const { error } = await supabase
          .from("campaign_submissions")
          .update({
            submission_link: link,
            status: "pending",
            submitted_at: new Date().toISOString(),
            revision_requested_at: null,
            updated_at: new Date().toISOString(),
          })
          .eq("id", participateSubmissionId);

        if (error) throw error;

        // refresh both lists
        await fetchCampaigns();
        await fetchMySubmissions();
        closeParticipateModal();
        alert(t("resubmission_success", lang));
      } else {
        // Normal path: create new submission and reserve a slot (existing RPC)
        const { error } = await supabase.rpc("reserve_campaign_slot_with_link", {
          p_campaign_id: participateModal.campaign!.id,
          p_submission_link: link,
        });
        if (error) throw error;

        await fetchCampaigns();
        await fetchMySubmissions();
        closeParticipateModal();
        alert(t("participation_success", lang));
      }
    } catch (err: unknown) {
      console.error("participate rpc err", err);
      const msg = (err as any)?.message ?? String(err);
      if (/Creators cannot participate/i.test(msg)) setSubmissionError(t("cannot_participate_own_campaign", lang));
      else if (/No remaining slots/i.test(msg)) setSubmissionError(t("campaign_full", lang));
      else setSubmissionError(msg);
    } finally {
      setRpcLoading(false);
      // cleanup resubmit flags so next open is fresh
      setParticipateIsResubmit(false);
      setParticipateSubmissionId(null);
    }
  };

  // --- resubmit flow ---

  const openResubmit = (submission: Submission): void => {
    setResubmitState({ open: true, submission });
    setResubmitLink(submission.submission_link ?? "");
    setResubmitError(null);
  };

  const closeResubmit = (): void => {
    setResubmitState({ open: false, submission: null });
    setResubmitLink("");
    setResubmitError(null);
  };

  const handleResubmit = async (): Promise<void> => {
    setResubmitError(null);
    setGeneralError(null);
    if (!resubmitState.submission) {
      setResubmitError(t("submission_context_lost", lang));
      return;
    }
    const submissionId = resubmitState.submission.id;
    const link = resubmitLink.trim();
    if (!link) {
      setResubmitError(t("paste_direct_link_prompt", lang));
      return;
    }
    if (!isValidSocialLink(link)) {
      setResubmitError(t("invalid_link", lang));
      return;
    }
    setResubmitLoading(true);
    try {
      const { error } = await supabase
        .from("campaign_submissions")
        .update({
          submission_link: link,
          status: "pending",
          submitted_at: new Date().toISOString(),
          revision_requested_at: null,
        })
        .eq("id", submissionId);
      if (error) throw error;
      await fetchMySubmissions();
      closeResubmit();
      alert(t("resubmission_sent", lang));
    } catch (err: unknown) {
      console.error("resubmit err", err);
      setResubmitError((err as any)?.message ?? String(err));
    } finally {
      setResubmitLoading(false);
    }
  };

  // --- timers helpers ---

  const computeTimersForSubmission = (s: Submission) => {
    const now = new Date(nowTs);
    let revisionRemaining = 0;
    let autoPayoutRemaining = 0;

    if (s.revision_requested_at) {
      const rev = new Date(s.revision_requested_at);
      const revExpiry = new Date(rev.getTime() + 48 * 60 * 60 * 1000); // +48 hours
      revisionRemaining = Math.max(revExpiry.getTime() - now.getTime(), 0);
    }

    if (s.submitted_at) {
      const sub = new Date(s.submitted_at);
      const autoExpiry = new Date(sub.getTime() + 7 * 24 * 60 * 60 * 1000); // +7 days
      autoPayoutRemaining = Math.max(autoExpiry.getTime() - now.getTime(), 0);
    }

    return { revisionRemaining, autoPayoutRemaining };
  };

  const formatMs = (ms: number) => {
    if (ms <= 0) return "0s";
    const totalSec = Math.floor(ms / 1000);
    const d = Math.floor(totalSec / (3600 * 24));
    const h = Math.floor((totalSec % (3600 * 24)) / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    const parts: string[] = [];
    if (d) parts.push(`${d}d`);
    if (h || d) parts.push(`${h}h`);
    if (m || h || d) parts.push(`${m}m`);
    parts.push(`${s}s`);
    return parts.join(" ");
  };

  // --- render ---
  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <div className={styles["header-logo"]}>
          <div className={styles["size-6"]} aria-hidden />
          <h2>{t("active_campaigns", lang)}</h2>
        </div>

        {/* Show joined campaigns summary (uses styles.badge for chips) */}
        <div className={styles["joined-summary"]}>
          <span className={styles["muted-ctx"]}>
            {t("participated_in", lang)} {Object.keys(joinedCampaigns).length}{" "}
            {Object.keys(joinedCampaigns).length !== 1 ? t("campaigns", lang) : t("campaign", lang)}
          </span>
          <div className={styles["joined-list"]} aria-hidden>
            {Object.entries(joinedCampaigns).map(([id, title]) => (
              <button key={id} className={styles.badge} onClick={() => navigate(`/campaigns/${id}`)} type="button" title={title}>
                {title}
              </button>
            ))}
          </div>
        </div>
      </header>

      {generalError && <div className={styles["muted"]}>{generalError}</div>}

      {loading ? (
        <div className={styles["muted-ctx"]}>{t("loading", lang)}</div>
      ) : campaigns.length === 0 ? (
        <div className={styles["muted-ctx"]}>{t("no_active_campaigns", lang)}</div>
      ) : (
        <div className={styles["table-wrapper"]}>
          <table>
            <thead>
              <tr>
                <th className={styles["font-medium"]}>{t("title", lang)}</th>
                <th className={styles["font-medium"]}>{t("description", lang)}</th>
                <th className={styles["font-medium"]}>{t("slots", lang)}</th>
                <th className={styles["font-medium"]}>{t("status", lang)}</th>
                <th className={styles["font-medium"]}>{t("action", lang)}</th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map((c) => {
                const isOwner = c.advertiser_id && userUid && c.advertiser_id === userUid;
                const userHasRevision = !!(userUid && findRevisionSubmissionForCampaign(c.id));
                return (
                  <tr key={c.id}>
                    <td>{c.title}</td>
                    <td>{c.description}</td>
                    <td>
                      {c.remaining_slots}/{c.total_slots}
                    </td>
                    <td>
                      <span className={`${styles.badge} ${c.remaining_slots > 0 ? styles["badge--active"] : styles["badge--completed"]}`}>
                        {c.remaining_slots > 0 ? t("open", lang) : t("full", lang)}
                      </span>
                    </td>
                    <td>
                      {isOwner ? (
                        <span className={styles["muted-ctx"]}>{t("your_campaign", lang)}</span>
                      ) : (
                        <button
                          className={styles["btn-primary"]}
                          onClick={() => openParticipateModal(c)}
                          disabled={!(c.remaining_slots > 0 || userHasRevision)}
                        >
                          {c.remaining_slots > 0 ? t("participate", lang) : userHasRevision ? t("resubmit", lang) : t("full", lang)}
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <hr className={styles["mx-auto"]} />

      <h2 className={styles["page-header"]}>{t("your_submissions", lang)}</h2>

      {mySubmissions.length === 0 ? (
        <div className={styles["muted-ctx"]}>{t("no_submissions_yet", lang)}</div>
      ) : (
        mySubmissions.map((s) => {
          const { revisionRemaining, autoPayoutRemaining } = computeTimersForSubmission(s);
          const showRevisionTimer = isRevisionRequested(s.status) && revisionRemaining > 0;
          const showAutoPayoutTimer = s.status === "pending" && autoPayoutRemaining > 0;
          const showAutoPayoutExpired = s.status === "pending" && autoPayoutRemaining <= 0;
          const campaignTitle = joinedCampaigns[s.campaign_id] ?? `Campaign ${s.campaign_id}`;

          return (
            <div key={s.id} className={styles["table-wrapper"]} style={{ padding: 12, marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 700 }}>
                    {campaignTitle}{" "}
                    <button className={styles["action"]} onClick={() => navigate(`/campaigns/${s.campaign_id}`)} type="button">
                      {t("view_campaign_details", lang)}
                    </button>
                  </div>
                  <div style={{ marginTop: 6 }}>
                    {t("status_label", lang)}: <span style={{ fontWeight: 600 }}>{s.status}</span>
                  </div>
                  <div style={{ marginTop: 6 }}>
                    {t("link_label", lang)}:{" "}
                    {s.submission_link ? (
                      <a href={s.submission_link} target="_blank" rel="noreferrer" className={styles["action"]}>
                        {t("view", lang)}
                      </a>
                    ) : (
                      "—"
                    )}
                  </div>
                </div>

                <div style={{ textAlign: "right", minWidth: 160 }}>
                  {isRevisionRequested(s.status) && (
                    <>
                      <div className={styles["countdown"]}>
                        <small className={styles["muted-ctx"]}>{t("time_to_resubmit", lang)}</small>
                        <div style={{ marginTop: 6, fontWeight: 700 }}>{showRevisionTimer ? formatMs(revisionRemaining) : t("expired", lang)}</div>
                      </div>

                      {showRevisionTimer ? (
                        <div style={{ marginTop: 8 }}>
                          <button className={styles["btn-ghost"]} onClick={() => openResubmit(s)}>
                            {t("resubmit", lang)}
                          </button>
                        </div>
                      ) : (
                        <div style={{ marginTop: 8 }} className={styles["muted-ctx"]}>
                          {t("revision_window_expired", lang)}
                        </div>
                      )}
                    </>
                  )}

                  {s.status === "pending" && (
                    <>
                      <div className={styles["countdown"]}>
                        <small className={styles["muted-ctx"]}>{t("auto_payout", lang)}</small>
                        <div style={{ marginTop: 6, fontWeight: 700 }}>
                          {showAutoPayoutTimer ? formatMs(autoPayoutRemaining) : showAutoPayoutExpired ? t("processing", lang) : "—"}
                        </div>
                      </div>
                      <div style={{ marginTop: 8 }} className={styles["muted-ctx"]}>
                        {t("auto_payout_info", lang)}
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })
      )}

      {/* Participate modal */}
      {participateModal.open && participateModal.campaign && (
        <div className={styles["modal-wrapper"]}>
          <div className={styles["modal-content"]}>
            <h3 className={styles["page-header"]}>
              {t("participate_in", lang)}: {participateModal.campaign.title}
            </h3>
            <p className={styles["muted-ctx"]}>
              {/* keep bold tag but translate surrounding text; we still want "direct" highlighted */}
              {t("paste_direct_link_instructions_part1", lang)} <strong>{t("direct", lang)}</strong> {t("paste_direct_link_instructions_part2", lang)}
            </p>

            <div className={styles["form-actions"]} style={{ marginTop: 12 }}>
              <label htmlFor="submissionLink">{t("submission_link_label", lang)}</label>
              <input
                id="submissionLink"
                type="url"
                value={submissionLink}
                onChange={(e) => setSubmissionLink(e.target.value)}
                placeholder="https://..."
                className={styles["form-input"]}
                disabled={rpcLoading}
              />
              {submissionError && <div className={styles["muted-ctx"]}>{submissionError}</div>}
            </div>

            <div className={styles["form-actions"]} style={{ marginTop: 12 }}>
              <button className={styles["btn-ghost"]} onClick={closeParticipateModal} disabled={rpcLoading}>
                {t("cancel", lang)}
              </button>
              <button className={styles["btn-primary"]} onClick={handleParticipateSubmit} disabled={rpcLoading}>
                {rpcLoading ? t("submitting", lang) : participateIsResubmit ? t("resubmit", lang) : t("submit_and_reserve_slot", lang)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Resubmit modal */}
      {resubmitState.open && resubmitState.submission && (
        <div className={styles["modal-wrapper"]}>
          <div className={styles["modal-content"]}>
            <h3 className={styles["page-header"]}>
              {t("resubmit_for_campaign", lang)} {resubmitState.submission.campaign_id}
            </h3>
            <p className={styles["muted-ctx"]}>{t("resubmit_instructions", lang)}</p>

            <div className={styles["form-actions"]} style={{ marginTop: 12 }}>
              <label htmlFor="resubmitLink">{t("new_submission_link", lang)}</label>
              <input
                id="resubmitLink"
                type="url"
                value={resubmitLink}
                onChange={(e) => setResubmitLink(e.target.value)}
                placeholder="https://..."
                className={styles["form-input"]}
                disabled={resubmitLoading}
              />
              {resubmitError && <div className={styles["muted-ctx"]}>{resubmitError}</div>}
            </div>

            <div className={styles["form-actions"]} style={{ marginTop: 12 }}>
              <button className={styles["btn-ghost"]} onClick={closeResubmit} disabled={resubmitLoading}>
                {t("cancel", lang)}
              </button>
              <button className={styles["btn-primary"]} onClick={handleResubmit} disabled={resubmitLoading}>
                {resubmitLoading ? t("resubmitting", lang) : t("resubmit", lang)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
