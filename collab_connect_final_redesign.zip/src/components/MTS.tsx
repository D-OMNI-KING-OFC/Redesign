import { useState } from "react";
import { t } from "../i18n/index";

type UnifiedResult = {
  platform: "youtube" | "twitter" | "tiktok" | "facebook" | "instagram";
  id: string;
  name?: string;
  username?: string;
  profilePic?: string;
  description?: string;
  followers?: number | null;
  verified?: boolean;
  raw?: any;
};

const TOTAL_RESULTS = 5;

// --- API keys / hosts (development) ---
const YT_API_KEY = "AIzaSyDGNK_RKC4i35Oz1OBcrUjWbTTVkK_NMHE";

const RAPID_TWITTER_KEY = "63c292b044msh90f551a27dd1f17p16659ejsn4ea90fcfdac2";
const RAPID_TWITTER_HOST = "twitter-x.p.rapidapi.com";

const RAPID_TIKTOK_KEY = "63c292b044msh90f551a27dd1f17p16659ejsn4ea90fcfdac2";
const RAPID_TIKTOK_HOST = "tiktok-api23.p.rapidapi.com";

const RAPID_FB_KEY = "63c292b044msh90f551a27dd1f17p16659ejsn4ea90fcfdac2";
const RAPID_FB_HOST = "facebook-scraper3.p.rapidapi.com";

const RAPID_IG_KEY = "63c292b044msh90f551a27dd1f17p16659ejsn4ea90fcfdac2";
const RAPID_IG_HOST = "instagram-social-api.p.rapidapi.com";

const safeNum = (v: any) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const maskDescription = (desc?: string, showFull = false) => {
  if (!desc) return "";
  if (showFull) return desc;
  const limit = 40; // show first 40 chars then mask
  if (desc.length <= limit) return desc;
  return desc.slice(0, limit) + " ******";
};

const PlatformIcon = ({ p }: { p: UnifiedResult["platform"] }) => {
  const style = { width: 18, height: 18, display: "inline-block", verticalAlign: "middle" } as const;
  switch (p) {
    case "youtube":
      return (
        <svg style={style} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="2" y="5" width="20" height="14" rx="4" fill="#FF0000" />
          <path d="M10 8.5v7l6-3.5-6-3.5z" fill="#fff" />
        </svg>
      );
    case "twitter":
      return (
        <svg style={style} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 5.92c-.63.28-1.31.48-2 .56a3.51 3.51 0 001.54-1.95 7.05 7.05 0 01-2.24.86 3.5 3.5 0 00-6 3.18A9.94 9.94 0 013 4.86a3.5 3.5 0 001.08 4.66 3.45 3.45 0 01-1.6-.44v.04a3.5 3.5 0 002.8 3.43 3.52 3.52 0 01-1.58.06 3.5 3.5 0 003.27 2.43A7.03 7.03 0 013 18.58a9.92 9.92 0 005.37 1.57c6.45 0 9.98-5.34 9.98-9.98 0-.15 0-.31-.01-.46A7.15 7.15 0 0022 5.92z" fill="#1DA1F2" />
        </svg>
      );
    case "tiktok":
      return (
        <svg style={style} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M17 3h-1.2a4 4 0 01-4 4v5a4 4 0 104 4V9h2V3z" fill="#010101" />
          <path d="M16.5 3v6.5a3 3 0 11-1.5-2.6V3z" fill="#69C9D0" />
          <path d="M13.5 14a3 3 0 11-2.9-3.04V14z" fill="#EE1D52" />
        </svg>
      );
    case "facebook":
      return (
        <svg style={style} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M15 3h3v4h-3v14h-4V7H8V3h3V1.5C11 1 11.7 1 12.3 1 13 1 15 1.6 15 1.6V3z" fill="#1877F2" />
        </svg>
      );
    case "instagram":
      return (
        <svg style={style} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="3" width="18" height="18" rx="5" fill="#E1306C" />
          <circle cx="12" cy="12" r="3.2" fill="#fff" />
          <circle cx="17.5" cy="6.5" r="0.9" fill="#fff" />
        </svg>
      );
    default:
      return null;
  }
};

async function fetchYouTube(query: string, perPlatformLimit: number): Promise<UnifiedResult[]> {
  try {
    if (!query) return [];
    const searchRes = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=${encodeURIComponent(query)}&maxResults=${perPlatformLimit}&key=${YT_API_KEY}`
    );
    const searchData = await searchRes.json();
    const channelIds = (searchData.items || []).map((i: any) => i.id.channelId).filter(Boolean).join(",");
    if (!channelIds) return [];
    const statsRes = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=statistics,snippet&id=${channelIds}&key=${YT_API_KEY}`
    );
    const statsData = await statsRes.json();
    const mapped =
      (statsData.items || []).map((channel: any) => {
        return {
          platform: "youtube" as const,
          id: channel.id,
          name: channel.snippet.title,
          username: channel.snippet.title,
          profilePic: channel.snippet.thumbnails?.default?.url,
          description: channel.snippet.description || "",
          followers: safeNum(channel.statistics?.subscriberCount) ?? null,
          verified: false,
          raw: channel,
        };
      }) || [];
    return mapped.slice(0, perPlatformLimit);
  } catch (e) {
    console.error("YouTube fetch error:", e);
    return [];
  }
}

async function fetchTwitter(query: string, perPlatformLimit: number): Promise<UnifiedResult[]> {
  try {
    if (!query) return [];
    const params = new URLSearchParams({ query, section: "top", limit: String(20) });
    const res = await fetch(`https://${RAPID_TWITTER_HOST}/search/?${params.toString()}`, {
      headers: {
        "x-rapidapi-key": RAPID_TWITTER_KEY,
        "x-rapidapi-host": RAPID_TWITTER_HOST,
        Accept: "application/json",
      },
    });
    if (!res.ok) {
      console.warn("Twitter API non-OK", await res.text());
      return [];
    }
    const raw = await res.json();
    const collected: any[] = [];
    if (raw?.globalObjects?.users) collected.push(...Object.values(raw.globalObjects.users));
    const found = (function collect(node: any, acc: any[]) {
      if (!node || typeof node !== "object") return;
      if (node?.screen_name || node?.screenName || node?.id_str) acc.push(node);
      for (const k of Object.keys(node)) {
        const v = node[k];
        if (v && typeof v === "object") collect(v, acc);
      }
      return acc;
    })(raw, []);
    if (found.length) collected.push(...found);
    const mapped = collected
      .map((u: any) => {
        const id = u.id_str || u.id || (u.user_id_str && String(u.user_id_str));
        const username = u.screen_name || u.username || (u.legacy && u.legacy.screen_name);
        return {
          platform: "twitter" as const,
          id: id ? String(id) : Math.random().toString(),
          name: u.name || username,
          username,
          profilePic: u.profile_image_url_https || u.profile_image_url || (u.legacy && u.legacy.profile_image_url_https),
          description: u.description || (u.legacy && u.legacy.description) || "",
          followers: safeNum(u.followers_count ?? (u.legacy && u.legacy.followers_count)) ?? null,
          verified: Boolean(u.verified || u.is_verified || (u.legacy && u.legacy.verified)),
          raw: u,
        } as UnifiedResult;
      })
      .filter(Boolean);
    const unique = Array.from(new Map(mapped.map((m) => [(m.id || m.username || Math.random()), m])).values());
    unique.sort((a, b) => Number(b.followers || 0) - Number(a.followers || 0));
    return unique.slice(0, perPlatformLimit);
  } catch (e) {
    console.error("Twitter fetch error:", e);
    return [];
  }
}

async function fetchTikTok(query: string, perPlatformLimit: number): Promise<UnifiedResult[]> {
  try {
    if (!query) return [];
    const params = new URLSearchParams({ keyword: query, cursor: "0", search_id: "0" });
    const res = await fetch(`https://${RAPID_TIKTOK_HOST}/api/search/account?${params.toString()}`, {
      headers: {
        "x-rapidapi-key": RAPID_TIKTOK_KEY,
        "x-rapidapi-host": RAPID_TIKTOK_HOST,
        Accept: "application/json",
      },
    });
    if (!res.ok) {
      console.warn("TikTok API non-OK", await res.text());
      return [];
    }
    const data = await res.json();
    let found: any[] = [];
    if (Array.isArray(data?.data)) found.push(...data.data);
    else if (Array.isArray(data?.data?.users)) found.push(...data.data.users);
    else if (Array.isArray(data?.users)) found.push(...data.users);
    if (found.length === 0) {
      const collect = (node: any, acc: any[]) => {
        if (!node || typeof node !== "object") return;
        if (node?.unique_id || node?.nickname || node?.user_id) acc.push(node);
        for (const k of Object.keys(node)) {
          const v = node[k];
          if (v && typeof v === "object") collect(v, acc);
        }
      };
      collect(data, found);
    }
    const mapped = found
      .map((u: any) => {
        const id = u.user_id || u.id || u.uid || (u.user && (u.user.id || u.user.user_id));
        const username = u.unique_id || u.uniqueId || u.username || (u.user && u.user.unique_id);
        return {
          platform: "tiktok" as const,
          id: id ? String(id) : Math.random().toString(),
          name: u.nickname || u.name || username,
          username,
          profilePic:
            (u.avatar_thumb && (u.avatar_thumb.url_list?.[0] || u.avatar_thumb.url)) ||
            u.avatar ||
            u.avatar_larger ||
            (u.user && u.user.avatar) ||
            undefined,
          description: u.signature || u.signature_txt || u.bio || u.description || "",
          followers: safeNum(u.follower_count ?? u.followerCount ?? u.user?.follower_count) ?? null,
          verified: false,
          raw: u,
        } as UnifiedResult;
      })
      .filter(Boolean);
    const unique = Array.from(new Map(mapped.map((m) => [(m.id || m.username || Math.random()), m])).values());
    unique.sort((a, b) => Number(b.followers || 0) - Number(a.followers || 0));
    return unique.slice(0, perPlatformLimit);
  } catch (e) {
    console.error("TikTok fetch error:", e);
    return [];
  }
}

async function fetchFacebookPages(query: string, perPlatformLimit: number): Promise<UnifiedResult[]> {
  try {
    if (!query) return [];
    const params = new URLSearchParams({ query });
    const res = await fetch(`https://${RAPID_FB_HOST}/search/pages?${params.toString()}`, {
      headers: {
        "x-rapidapi-key": RAPID_FB_KEY,
        "x-rapidapi-host": RAPID_FB_HOST,
        Accept: "application/json",
      },
    });
    if (!res.ok) {
      console.warn("FB API non-OK", await res.text());
      return [];
    }
    const data = await res.json();
    let items: any[] = [];
    if (Array.isArray(data)) items = data;
    else if (Array.isArray(data?.data)) items = data.data;
    else if (Array.isArray(data?.results)) items = data.results;
    else if (Array.isArray(data?.pages)) items = data.pages;
    else if (Array.isArray(data?.profiles)) items = data.profiles;
    if (items.length === 0) {
      const found: any[] = [];
      (function collect(node: any) {
        if (!node || typeof node !== "object") return;
        if (node?.name && (node?.id || node?.page_id)) found.push(node);
        for (const k of Object.keys(node)) {
          const v = node[k];
          if (v && typeof v === "object") collect(v);
        }
      })(data);
      items = found;
    }
    const mapped = items
      .map((p: any) => {
        const id = p.id || p.page_id || (p.data && (p.data.id || p.data.page_id));
        const name = p.name || p.title || p.page_name || (p.data && p.data.name);
        const profilePic = p.profile_pic || p.picture || (p.data && p.data.profile_pic) || undefined;
        const description = p.description || p.about || (p.data && p.data.about) || "";
        const followers = safeNum(p.followers ?? p.fan_count ?? p.likes ?? (p.data && p.data.followers)) ?? null;
        const verified = Boolean(p.verified || p.is_verified || p.isVerified || p.is_verified_account);
        return {
          platform: "facebook" as const,
          id: id ? String(id) : Math.random().toString(),
          name,
          username: name,
          profilePic,
          description,
          followers,
          verified,
          raw: p,
        } as UnifiedResult;
      })
      .filter(Boolean);
    const unique = Array.from(new Map(mapped.map((m) => [(m.id || m.name || Math.random()), m])).values());
    unique.sort((a, b) => Number(b.followers || 0) - Number(a.followers || 0));
    return unique.slice(0, perPlatformLimit);
  } catch (e) {
    console.error("Facebook fetch error:", e);
    return [];
  }
}

async function fetchInstagram(query: string, perPlatformLimit: number): Promise<UnifiedResult[]> {
  try {
    if (!query) return [];
    const params = new URLSearchParams({ search_query: query });
    const res = await fetch(`https://${RAPID_IG_HOST}/v1/search_users?${params.toString()}`, {
      headers: {
        "x-rapidapi-key": RAPID_IG_KEY,
        "x-rapidapi-host": RAPID_IG_HOST,
        Accept: "application/json",
      },
    });
    if (!res.ok) {
      console.warn("IG API non-OK", await res.text());
      return [];
    }
    const data = await res.json();
    const items = Array.isArray(data?.data?.items) ? data.data.items : Array.isArray(data?.users) ? data.users : [];
    if (!items.length) return [];
    const mapped = items.map((u: any) => ({
      platform: "instagram" as const,
      id: u.id ? String(u.id) : Math.random().toString(),
      name: u.full_name || u.username,
      username: u.username,
      profilePic: u.profile_pic_url || undefined,
      description: u.biography || "",
      followers: safeNum(u.follower_count) ?? null,
      verified: Boolean(u.is_verified),
      raw: u,
    }));
    mapped.sort((a: { followers: any }, b: { followers: any }) => Number(b.followers || 0) - Number(a.followers || 0));
    return mapped.slice(0, perPlatformLimit);
  } catch (e) {
    console.error("Instagram fetch error:", e);
    return [];
  }
}

export default function MultiPlatformSearchBar(lang: string)  {
  const [query, setQuery] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<
    { key: UnifiedResult["platform"]; label: string; checked: boolean }[]
  >([
    { key: "youtube", label: "YouTube", checked: true },
    { key: "twitter", label: "Twitter", checked: true },
    { key: "tiktok", label: "TikTok", checked: true },
    { key: "facebook", label: "Facebook", checked: true },
    { key: "instagram", label: "Instagram", checked: true },
  ]);
  const [minFollowers, setMinFollowers] = useState<number | "">("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<UnifiedResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showFullDescriptions] = useState(false);

  const togglePlatform = (key: UnifiedResult["platform"]) => {
    setSelectedPlatforms((prev) => prev.map((p) => (p.key === key ? { ...p, checked: !p.checked } : p)));
  };

  const setAllPlatforms = (on: boolean) => setSelectedPlatforms((prev) => prev.map((p) => ({ ...p, checked: on })));

  const cardBg = "rgba(255,255,255,0.06)";
  const cardBorder = "1px solid rgba(255,255,255,0.14)";
  const ink1 = "rgba(255,255,255,0.92)";
  const ink2 = "rgba(255,255,255,0.72)";

  const handleSearch = async () => {
    setError(null);
    setResults([]);
    if (!query.trim()) {
      setError("Type a keyword (e.g. crypto, fitness)");
      return;
    }

    const active = selectedPlatforms.filter((p) => p.checked).map((p) => p.key);
    if (active.length === 0) {
      setError("Select at least one platform to search.");
      return;
    }

    const perPlatform = Math.max(1, Math.floor(TOTAL_RESULTS / active.length));
    setLoading(true);

    try {
      const calls: Promise<UnifiedResult[]>[] = [];
      for (const platform of active) {
        switch (platform) {
          case "youtube":
            calls.push(fetchYouTube(query, perPlatform));
            break;
          case "twitter":
            calls.push(fetchTwitter(query, perPlatform));
            break;
          case "tiktok":
            calls.push(fetchTikTok(query, perPlatform));
            break;
          case "facebook":
            calls.push(fetchFacebookPages(query, perPlatform));
            break;
          case "instagram":
            calls.push(fetchInstagram(query, perPlatform));
            break;
        }
      }

      const settled = await Promise.allSettled(calls);
      let combined: UnifiedResult[] = [];
      for (const s of settled) {
        if (s.status === "fulfilled" && Array.isArray(s.value)) {
          combined.push(...s.value);
        } else {
          console.warn("Platform fetch failed:", s);
        }
      }

      if (minFollowers !== "") {
        const min = Number(minFollowers);
        combined = combined.filter((r) => {
          if (r.followers == null) return false;
          return Number(r.followers) >= min;
        });
      }

      const deduped = Array.from(new Map(combined.map((r) => [`${r.platform}:${r.id}`, r])).values());

      const byPlatformMap = new Map<string, UnifiedResult[]>();
      for (const p of selectedPlatforms.filter((s) => s.checked).map((s) => s.key)) byPlatformMap.set(p, []);
      for (const r of deduped) {
        const arr = byPlatformMap.get(r.platform) ?? [];
        if (arr.length < perPlatform) arr.push(r);
        byPlatformMap.set(r.platform, arr);
      }
      let final: UnifiedResult[] = [];
      for (const p of selectedPlatforms.filter((s) => s.checked).map((s) => s.key)) {
        final.push(...(byPlatformMap.get(p) || []));
      }

      if (final.length < TOTAL_RESULTS) {
        const remaining = deduped.filter((d) => !final.some((f) => f.platform === d.platform && f.id === d.id));
        final.push(...remaining.slice(0, TOTAL_RESULTS - final.length));
      }

      final = final.slice(0, TOTAL_RESULTS);

      setResults(final);
      if (final.length === 0) setError("No influencer results found (try fewer filters or select more platforms).");
    } catch (err: any) {
      console.error("Multi-platform search error:", err);
      setError("Search failed — check console.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        padding: 16,
        display: "flex",
        flexDirection: "column",
        gap: 12,
        width: "100%",
        maxWidth: "clamp(600px, 90vw, 1200px)",
        margin: "0 auto",
        boxSizing: "border-box",
        color: ink1,
      }}
    >
      {/* Search bar */}
      <div style={{ display: "flex", gap: 12, alignItems: "center", width: "100%" }}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("ytsearch_placeholder", lang)}
          style={{
            flex: 3,
            padding: "0.85rem 1rem",
            borderRadius: 12,
            border: "1px solid rgba(160,190,255,0.22)",
            background: "rgba(8,14,28,0.65)",
            color: ink1,
            outline: "none",
            boxShadow: "0 6px 18px rgba(0,0,0,0.25) inset",
            fontSize: "clamp(14px, 1.6vw, 16px)",
            width: "100%",
            minWidth: 0,
          }}
        />

        <div style={{ flex: 1, display: "flex", gap: 8, alignItems: "center", justifyContent: "flex-end", minWidth: 0 }}>
          <input
            type="number"
            min={0}
            placeholder="Min followers"
            value={minFollowers as any}
            onChange={(e) => setMinFollowers(e.target.value === "" ? "" : Number(e.target.value))}
            style={{
              width: "clamp(90px, 12vw, 160px)",
              padding: "0.6rem 0.8rem",
              borderRadius: 10,
              border: "1px solid rgba(160,190,255,0.22)",
              background: "rgba(8,14,28,0.65)",
              color: ink1,
              fontSize: "clamp(13px, 1.3vw, 14px)",
              boxSizing: "border-box",
              outline: "none",
            }}
          />

          <button
            onClick={handleSearch}
            disabled={loading}
            style={{
              padding: "0.7rem 1.1rem",
              background: "linear-gradient(90deg, #0b66ff, #0056ff)",
              color: "#fff",
              borderRadius: 10,
              border: "none",
              fontSize: "clamp(14px, 1.4vw, 15px)",
              minWidth: "clamp(98px, 12vw, 150px)",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 8px 24px rgba(11,102,255,0.35)",
              cursor: "pointer",
            }}
          >
            {loading ? t("searching", lang) : t("ytsearch_button", lang)}
          </button>
        </div>
      </div>

      {/* Platform filters */}
      <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", justifyContent: "space-between" }}>
        <label style={{ display: "flex", gap: 8, alignItems: "center", minWidth: 0, color: ink2 }}>
          <input
            type="checkbox"
            checked={selectedPlatforms.every((p) => p.checked)}
            onChange={(e) => setAllPlatforms(e.target.checked)}
          />
          <span style={{ fontSize: "clamp(13px, 1.2vw, 14px)" }}>Select all</span>
        </label>

        <div
          style={{
            display: "flex",
            gap: 8,
            alignItems: "center",
            flexWrap: "wrap",
            overflowX: "auto",
            paddingBottom: 4,
            msOverflowStyle: "none" as any,
            scrollbarWidth: "none" as any,
          }}
        >
          {selectedPlatforms.map((p) => (
            <label
              key={p.key}
              style={{
                display: "inline-flex",
                gap: 6,
                alignItems: "center",
                padding: "6px 10px",
                borderRadius: 999,
                background: p.checked ? "rgba(11,102,255,0.14)" : "rgba(255,255,255,0.06)",
                border: p.checked ? "1px solid rgba(11,102,255,0.45)" : "1px solid rgba(255,255,255,0.18)",
                whiteSpace: "nowrap",
                fontSize: "clamp(13px, 1.2vw, 14px)",
                color: ink2,
                cursor: "pointer",
              }}
            >
              <input type="checkbox" checked={p.checked} onChange={() => togglePlatform(p.key)} style={{ width: 16, height: 16 }} />
              <span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
                <PlatformIcon p={p.key} /> {p.label}
              </span>
            </label>
          ))}
        </div>
      </div>

      {error && <div style={{ color: "#ffb4b4", marginBottom: 12 }}>{error}</div>}

      {/* Results */}
      <div style={{ display: "grid", gap: 12, gridTemplateColumns: "1fr" }}>
        {results.map((r) => (
          <div
            key={`${r.platform}:${r.id}`}
            style={{
              display: "flex",
              gap: 12,
              padding: 14,
              borderRadius: 14,
              border: cardBorder,
              alignItems: "center",
              background: cardBg,
              boxShadow: "0 1px 2px rgba(16,24,40,0.15)",
              flexWrap: "wrap",
            }}
          >
            <img
              src={
                r.profilePic ||
                undefined ||
                "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='100%' height='100%' fill='%23111'/></svg>"
              }
              alt={r.name || r.username}
              style={{
                width: "clamp(56px, 12vw, 96px)",
                height: "clamp(56px, 12vw, 96px)",
                borderRadius: 10,
                objectFit: "cover",
                background: "#0b0f1a",
                flex: "0 0 auto",
              }}
              onError={(e) => {
                const t = e.target as HTMLImageElement;
                t.src = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='100%' height='100%' fill='%23111'/></svg>";
              }}
            />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                <div style={{ display: "inline-flex", gap: 8, alignItems: "center", color: ink1 }}>
                  <PlatformIcon p={r.platform} />
                  <strong style={{ fontSize: "clamp(15px, 1.6vw, 17px)" }}>{r.name || r.username}</strong>
                  {r.verified && (
                    <span
                      style={{
                        color: "#0b66ff",
                        fontSize: 12,
                        padding: "2px 8px",
                        borderRadius: 999,
                        background: "rgba(11,102,255,0.14)",
                        border: "1px solid rgba(11,102,255,0.45)",
                      }}
                    >
                      Verified
                    </span>
                  )}
                </div>
                <div style={{ marginLeft: "auto", color: ink2, fontSize: "clamp(12px, 1.2vw, 13px)" }}>
                  {r.followers != null ? `${Number(r.followers).toLocaleString()} followers` : "Followers: ?"}
                </div>
              </div>

              <div style={{ color: ink2, marginTop: 8, fontSize: "clamp(13px, 1.2vw, 14px)" }}>
                {maskDescription(r.description, showFullDescriptions)}
              </div>
              <div style={{ marginTop: 8 }}>
                <button
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#b5ccff",
                    cursor: "pointer",
                    fontWeight: 700,
                    padding: 0,
                    fontSize: "clamp(13px, 1.2vw, 14px)",
                  }}
                >
                  View profile
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CTA */}
      <div style={{ marginTop: 14, textAlign: "center" }}>
        <div style={{ marginBottom: 8, color: ink2, fontSize: "clamp(13px, 1.2vw, 14px)" }}>
          Full descriptions are hidden — sign up to view full results.
        </div>
        <a
          href="/signup"
          onClick={(_e) => {}}
          style={{
            padding: "0.7rem 1.1rem",
            background: "linear-gradient(90deg, #0b66ff, #0056ff)",
            color: "#fff",
            borderRadius: 10,
            textDecoration: "none",
            display: "inline-block",
            fontSize: "clamp(14px, 1.4vw, 15px)",
            boxShadow: "0 8px 24px rgba(11,102,255,0.35)",
          }}
        >
          Sign up to see full results
        </a>
      </div>
    </div>
  );
}
