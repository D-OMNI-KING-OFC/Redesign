// src/components/CampaignCreation.tsx
import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabaseClient";
import styles from "./CampaignCreation.module.css";
import { t } from "../i18n/index";

type cpprops = {
  lang: string;
};

type FieldErrors = Partial<
  Record<
    | "title"
    | "description"
    | "category"
    | "target_platform"
    | "reward_per_post"
    | "total_slots"
    | "deadline"
    | "media_url"
    | "general",
    string
  >
>;

const MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024; // 50 MB
const ALLOWED_FILE_PREFIXES = ["image/", "video/"];

export default function CampaignCreation({ lang }: cpprops) {
  const navigate = useNavigate();

  // inputs as strings to avoid TS number/string pitfalls
  const [title, setTitle] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [category, setCategory] = useState<string>("");
  const [targetPlatform, setTargetPlatform] = useState<string>("");
  const [deadline, setDeadline] = useState<string>("");
  const [rewardPerPost, setRewardPerPost] = useState<string>("");
  const [totalPosts, setTotalPosts] = useState<string>("1");
  const [file, setFile] = useState<File | null>(null);

  const [loading, setLoading] = useState<boolean>(false);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [success, setSuccess] = useState<string>("");

  // Refs
  const titleRef = useRef<HTMLInputElement | null>(null);
  const descRef = useRef<HTMLTextAreaElement | null>(null);
  const categoryRef = useRef<HTMLSelectElement | null>(null);
  const targetPlatformRef = useRef<HTMLInputElement | null>(null);
  const rewardRef = useRef<HTMLInputElement | null>(null);
  const totalRef = useRef<HTMLInputElement | null>(null);
  const deadlineRef = useRef<HTMLInputElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  // Helpers
  const isAllowedFileType = (f: File) => ALLOWED_FILE_PREFIXES.some((p) => f.type.startsWith(p));

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrors((s) => ({ ...s, media_url: undefined }));
    const files = e.target.files;
    if (!files || files.length === 0) {
      setFile(null);
      return;
    }
    const f = files[0];
    if (!isAllowedFileType(f)) {
      setFile(null);
      setErrors((s) => ({ ...s, media_url: t("unsupported_file_type", lang) }));
      return;
    }
    if (f.size > MAX_FILE_SIZE_BYTES) {
      setFile(null);
      setErrors((s) => ({ ...s, media_url: t("file_too_large", lang) }));
      return;
    }
    setFile(f);
  };

  const validateAll = async (): Promise<boolean> => {
    const newErrors: FieldErrors = {};

    if (!title.trim()) newErrors.title = t("campaign_title_required", lang);
    if (!description.trim()) newErrors.description = t("describe_campaign", lang);
    if (!category.trim()) newErrors.category = t("select_campaign_type", lang);
    if (!targetPlatform.trim()) newErrors.target_platform = t("specify_target_platform", lang);

    const reward = parseFloat(rewardPerPost === "" ? "NaN" : rewardPerPost);
    if (isNaN(reward) || reward <= 0) newErrors.reward_per_post = t("reward_must_be_number", lang);

    const total = parseInt(totalPosts === "" ? "0" : totalPosts, 10);
    if (isNaN(total) || total < 1) newErrors.total_slots = t("total_posts_must_be_integer", lang);

    if (deadline) {
      const parsed = Date.parse(deadline);
      if (Number.isNaN(parsed)) newErrors.deadline = t("invalid_date_time", lang);
      else if (parsed <= Date.now()) newErrors.deadline = t("deadline_in_future", lang);
    }

    if (file && file.size > MAX_FILE_SIZE_BYTES) newErrors.media_url = t("file_too_large", lang);

    setErrors(newErrors);

    // Focus first invalid field
    const order: Array<{ key: keyof FieldErrors; ref?: React.RefObject<any> }> = [
      { key: "title", ref: titleRef },
      { key: "description", ref: descRef },
      { key: "category", ref: categoryRef },
      { key: "target_platform", ref: targetPlatformRef },
      { key: "reward_per_post", ref: rewardRef },
      { key: "total_slots", ref: totalRef },
      { key: "deadline", ref: deadlineRef },
      { key: "media_url", ref: fileRef },
    ];

    for (const o of order) {
      if (newErrors[o.key]) {
        if (o.ref && o.ref.current && typeof o.ref.current.focus === "function") {
          o.ref.current.focus();
        }
        break;
      }
    }

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setSuccess("");

    const ok = await validateAll();
    if (!ok) return;

    setLoading(true);

    try {
      // get session & advertiser uuid
      const { data: sessionData } = await supabase.auth.getSession();
      const session = (sessionData as any)?.session ?? null;
      const advertiser_id: string | null = session?.user?.id ?? null;

      if (!advertiser_id) {
        setErrors({ general: t("must_be_signed_in_create", lang) });
        setLoading(false);
        return;
      }

      // Upload file if present
      let publicUrl: string | null = null;
      if (file) {
        // place file under the user's folder to satisfy bucket policies (e.g. "uuid/filename")
        const safeFileName = `${Date.now()}_${file.name.replace(/\s+/g, "_")}`;
        const filePath = `${advertiser_id}/${safeFileName}`;

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("campaign-media")
          .upload(filePath, file, { upsert: false });

        if (uploadError) {
          setErrors({ media_url: `${t("file_upload_failed_prefix", lang)} ${uploadError.message}` });
          setLoading(false);
          return;
        }

        // get public URL
        const { data: urlData, error: urlError } = await supabase.storage.from("campaign-media").getPublicUrl(filePath);
        if (urlError) {
          // not fatal — we can still store null, but surface the error
          setErrors((s) => ({ ...s, media_url: `${t("could_not_get_public_url_prefix", lang)} ${urlError.message}` }));
        } else {
          publicUrl = (urlData as any)?.publicUrl ?? null;
        }
      }

      // parse numbers safely
      const rewardNum = parseFloat(rewardPerPost);
      const totalNum = parseInt(totalPosts, 10);

      const reward_amount = Number.isFinite(rewardNum) && Number.isFinite(totalNum) ? rewardNum * totalNum : 0;

      // Build payload matching ad_requests columns
      const payload = {
        advertiser_id, // uuid
        title: title.trim(),
        description: description.trim() || null,
        category: category || null,
        target_platform: targetPlatform || null,
        deadline: deadline || null,
        media_url: publicUrl,
        reward_amount: reward_amount,
        reward_per_post: rewardNum,
        total_slots: totalNum,
        remaining_slots: totalNum,
        status: "pending",
      };

      const { error: insertError } = await supabase.from("ad_requests").insert([payload]);

      if (insertError) {
        if (/(row-level security|RLS|policy)/i.test(insertError.message)) {
          setErrors({
            general: `${t("permission_denied_rls_prefix", lang)} ${t("permission_denied_rls_suffix", lang)}`,
          });
        } else {
          setErrors({ general: `${t("database_error_prefix", lang)} ${insertError.message}` });
        }
        setLoading(false);
        return;
      }

      // success
      setSuccess(t("campaign_created_success", lang));
      // reset form
      setTitle("");
      setDescription("");
      setCategory("");
      setTargetPlatform("");
      setDeadline("");
      setRewardPerPost("");
      setTotalPosts("1");
      setFile(null);

      // navigate away after success
      navigate("/dashboard");
    } catch (err: any) {
      setErrors({ general: `${t("unexpected_error_prefix", lang)} ${err?.message ?? String(err)}` });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles["max-w-4xl"] ?? ""} style={{ margin: "0 auto", width: "100%" }}>
        <div className={styles.card}>
          <div className={styles["step-row"]} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div className="left" style={{ fontWeight: 600 }}>{t("step_1_of_4_campaign_details", lang)}</div>
            <div className="right" style={{ color: "var(--primary)", fontWeight: 600 }}>{t("progress_25_complete", lang)}</div>
          </div>

          <div style={{ marginTop: 8 }}>
            <div className={styles["progress-track"]}>
              <div className={styles["progress-fill"]} style={{ width: "25%" }} />
            </div>
          </div>

          <form onSubmit={handleSubmit} className={styles["form-stack"] ?? ""} style={{ marginTop: 24 }} noValidate>
            <div className={styles["form-grid"] ?? ""}>
              <div>
                <label htmlFor="title">{t("campaign_name_label", lang)}</label>
                <input
                  id="title"
                  name="title"
                  type="text"
                  ref={titleRef}
                  className={styles.input}
                  placeholder={t("campaign_name_placeholder", lang)}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  aria-invalid={!!errors.title}
                  aria-describedby={errors.title ? "error-title" : undefined}
                />
                {errors.title && <div id="error-title" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.title}</div>}
              </div>

              <div>
                <label htmlFor="budget">{t("budget_label", lang)}</label>
                <div className={styles["input-with-icon"] ?? ""} style={{ position: "relative" }}>
                  <div className={styles["icon-left"] ?? ""} style={{ left: 12, position: "absolute", top: "50%", transform: "translateY(-50%)" }}>
                    {t("currency_symbol", lang)}
                  </div>
                  <input id="budget" name="budget" type="text" className={styles.input} placeholder={t("budget_placeholder", lang)} aria-label={t("campaign_budget_aria", lang)} />
                </div>
              </div>

              <div>
                <label htmlFor="campaign-objective">{t("campaign_objective_label", lang)}</label>
                <select id="campaign-objective" name="campaign_objective" className={styles.select}>
                  <option value="">{t("select_objective", lang)}</option>
                  <option>{t("objective_brand_awareness", lang)}</option>
                  <option>{t("objective_lead_generation", lang)}</option>
                  <option>{t("objective_sales_conversion", lang)}</option>
                </select>
              </div>

              <div>
                <label htmlFor="category">{t("campaign_type_label", lang)}</label>
                <select
                  id="category"
                  name="category"
                  ref={categoryRef}
                  className={styles.select}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  aria-invalid={!!errors.category}
                  aria-describedby={errors.category ? "error-category" : undefined}
                >
                  <option value="">{t("select_type", lang)}</option>
                  <option value="Sponsored Posts">{t("sponsored_posts", lang)}</option>
                  <option value="Product Reviews">{t("product_reviews", lang)}</option>
                  <option value="Brand Ambassadorship">{t("brand_ambassadorship", lang)}</option>
                </select>
                {errors.category && <div id="error-category" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.category}</div>}
              </div>
            </div>

            {/* Target audience */}
            <div>
              <h3 style={{ margin: 0, fontSize: "1.125rem", fontWeight: 600 }}>{t("target_audience", lang)}</h3>
              <div className={styles["form-grid"] ?? ""} style={{ marginTop: 12 }}>
                <div>
                  <label htmlFor="target_demographics">{t("target_demographics_label", lang)}</label>
                  <select id="target_demographics" name="target_demographics" className={styles.select}>
                    <option value="">{t("select_demographics", lang)}</option>
                    <option>{t("demo_18_24_female_fitness", lang)}</option>
                    <option>{t("demo_25_34_male_tech", lang)}</option>
                    <option>{t("demo_35_44_all_travel", lang)}</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="target_platform">{t("target_platform_label", lang)}</label>
                  <input
                    id="target_platform"
                    name="target_platform"
                    type="text"
                    ref={targetPlatformRef}
                    className={styles.input}
                    value={targetPlatform}
                    onChange={(e) => setTargetPlatform(e.target.value)}
                    aria-invalid={!!errors.target_platform}
                    aria-describedby={errors.target_platform ? "error-target_platform" : undefined}
                  />
                  {errors.target_platform && <div id="error-target_platform" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.target_platform}</div>}
                </div>
              </div>
            </div>

            {/* Deliverables */}
            <div>
              <h3 style={{ margin: 0, fontSize: "1.125rem", fontWeight: 600 }}>{t("deliverables", lang)}</h3>
              <div style={{ marginTop: 12 }}>
                <label htmlFor="description" className={styles["sr-only"]}>{t("deliverables", lang)}</label>
                <textarea
                  id="description"
                  name="description"
                  ref={descRef}
                  className={styles.textarea}
                  placeholder={t("deliverables_placeholder", lang)}
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  aria-invalid={!!errors.description}
                  aria-describedby={errors.description ? "error-description" : undefined}
                />
                {errors.description && <div id="error-description" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.description}</div>}
              </div>
            </div>

            {/* Reward & Slots */}
            <div className={styles["form-grid"] ?? ""}>
              <div>
                <label htmlFor="reward_per_post">{t("reward_per_post_label", lang)}</label>
                <input
                  id="reward_per_post"
                  name="reward_per_post"
                  type="number"
                  step="0.01"
                  ref={rewardRef}
                  className={styles.input}
                  placeholder={t("reward_placeholder", lang)}
                  value={rewardPerPost}
                  onChange={(e) => setRewardPerPost(e.target.value)}
                  aria-invalid={!!errors.reward_per_post}
                  aria-describedby={errors.reward_per_post ? "error-reward_per_post" : undefined}
                />
                {errors.reward_per_post && <div id="error-reward_per_post" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.reward_per_post}</div>}
              </div>

              <div>
                <label htmlFor="total_slots">{t("number_of_posts_label", lang)}</label>
                <input
                  id="total_slots"
                  name="total_slots"
                  type="number"
                  min={1}
                  ref={totalRef}
                  className={styles.input}
                  placeholder={t("number_of_posts_placeholder", lang)}
                  value={totalPosts}
                  onChange={(e) => setTotalPosts(e.target.value)}
                  aria-invalid={!!errors.total_slots}
                  aria-describedby={errors.total_slots ? "error-total_slots" : undefined}
                />
                {errors.total_slots && <div id="error-total_slots" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.total_slots}</div>}
              </div>
            </div>

            {/* Deadline & File */}
            <div className={styles["form-grid"] ?? ""}>
              <div>
                <label htmlFor="deadline">{t("deadline_label", lang)}</label>
                <input
                  id="deadline"
                  name="deadline"
                  type="datetime-local"
                  ref={deadlineRef}
                  className={styles.input}
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  aria-invalid={!!errors.deadline}
                  aria-describedby={errors.deadline ? "error-deadline" : undefined}
                />
                {errors.deadline && <div id="error-deadline" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.deadline}</div>}
              </div>

              <div>
                <label htmlFor="media_url">{t("upload_media_label", lang)}</label>
                <input
                  id="media_url"
                  name="media_url"
                  type="file"
                  accept="image/*,video/*"
                  ref={fileRef}
                  className={styles.input}
                  onChange={handleFileChange}
                  aria-invalid={!!errors.media_url}
                  aria-describedby={errors.media_url ? "error-media_url" : undefined}
                />
                {/* Media Preview */}
                {file && (
                  <div style={{ marginTop: 12 }}>
                    {file.type.startsWith("image/") ? (
                      <img
                        src={URL.createObjectURL(file)}
                        alt={t("selected_media_preview", lang)}
                        style={{ maxWidth: "50%", maxHeight: 150, borderRadius: 8 }}
                      />
                    ) : file.type.startsWith("video/") ? (
                      <video
                        src={URL.createObjectURL(file)}
                        controls
                        style={{ maxWidth: "50%", maxHeight: 150, borderRadius: 8 }}
                      />
                    ) : null}
                  </div>
                )}

                {errors.media_url && <div id="error-media_url" role="alert" style={{ color: "hsl(0 75% 50%)", marginTop: 6 }}>{errors.media_url}</div>}
              </div>
            </div>

            <div className={styles["form-actions"] ?? ""}>
              <button
                type="button"
                className={styles["btn-ghost"] ?? ""}
                onClick={() => {
                  navigate("/dashboard");
                }}
              >
                {t("cancel_button", lang)}
              </button>

              <button type="submit" disabled={loading} className={styles["btn-primary"] ?? ""}>
                {loading ? t("creating", lang) : t("next_step", lang)}
              </button>
            </div>
          </form>

          <div style={{ marginTop: 12 }}>
            {errors.general && <p role="alert" style={{ color: "hsl(0 75% 50%)", margin: 0 }}>{errors.general}</p>}
            {success && <p role="status" style={{ color: "hsl(140 40% 35%)", margin: 0 }}>{success}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

