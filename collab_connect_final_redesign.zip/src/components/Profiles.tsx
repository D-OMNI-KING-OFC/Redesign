// src/components/Profile.tsx
import React, { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import styles from "./InfluencerCards.module.css";
import { t } from "../i18n/index";

type ProfileRow = {
  id: number;
  created_at: string | null;
  platforms: any; // jsonb
  industries: string[];
  pricing_range?: string | null;
  follower_count?: number | null;
  budget_range?: string | null;
  role?: string | null;
  auth_uid?: string | null;
  budget?: number | null;
  role_locked?: boolean | null;
};

type Props = {
  // optional: if uid passed we'll load that profile, otherwise fall back to session user
  uid?: string | null;
  lang: string;
};

export default function Profile({ uid: propUid, lang }: Props): JSX.Element {
  const [profile, setProfile] = useState<ProfileRow | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionUid, setSessionUid] = useState<string | null>(null);
  const [authMeta, setAuthMeta] = useState<any>(null); // to read user metadata like email/name

  // fetch session uid + metadata
  const fetchSession = async (): Promise<string | null> => {
    try {
      const { data } = await supabase.auth.getSession();
      const session = (data as any)?.session ?? null;
      const uid = session?.user?.id ?? null;
      setSessionUid(uid);
      setAuthMeta(session?.user ?? null);
      return uid;
    } catch (err) {
      console.error("fetchSession error", err);
      setSessionUid(null);
      setAuthMeta(null);
      return null;
    }
  };

  const fetchProfile = async (targetUid?: string | null) => {
    setLoading(true);
    setError(null);
    try {
      const uidToUse = targetUid ?? propUid ?? (await fetchSession());
      if (!uidToUse) {
        setProfile(null);
        setLoading(false);
        setError(t("not_signed_in", lang));
        return;
      }

      const { data, error } = await supabase
        .from<ProfileRow>("profiles")
        .select("*")
        .eq("auth_uid", uidToUse)
        .single();

      if (error) {
        // if no rows, supabase may return an error message containing "No rows"
        if ((error as any)?.message && /no rows/i.test((error as any).message)) {
          setProfile(null);
          setError(t("profile_not_found", lang));
        } else {
          setProfile(null);
          setError((error as any)?.message ?? String(error));
        }
      } else {
        setProfile(data ?? null);
        setError(null);
      }
    } catch (err: any) {
      console.error("fetchProfile exception", err);
      setProfile(null);
      setError(err?.message ?? String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // load session + profile on mount
    (async () => {
      // if propUid is provided, we still fetch session to determine "isOwner"
      await fetchSession();
      await fetchProfile(propUid ?? undefined);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [propUid, lang]);

  const isOwner = Boolean(sessionUid && profile && sessionUid === profile.auth_uid);

  // readable display helpers
  const displayName = (() => {
    // prefer auth metadata (if available), else show short uid
    const metaName = (authMeta && (authMeta.user_metadata?.full_name || authMeta.user_metadata?.name || authMeta.email)) ?? null;
    if (metaName) return metaName;
    if (profile?.auth_uid) return `User ${profile.auth_uid.slice(0, 8)}`;
    return t("no_website", lang); // fallback short label
  })();

  const platformsList = (() => {
    try {
      if (!profile) return [];
      if (Array.isArray(profile.platforms)) return profile.platforms;
      if (typeof profile.platforms === "string") {
        const parsed = JSON.parse(profile.platforms);
        return Array.isArray(parsed) ? parsed : [];
      }
      // if it's an object with keys, convert to array
      if (profile.platforms && typeof profile.platforms === "object") {
        return Object.values(profile.platforms);
      }
      return [];
    } catch {
      return [];
    }
  })();

  return (
    <div className="neon-card">
<div className={styles.container}>
      <div className={styles.card} style={{ maxWidth: 1000, margin: "0 auto" }}>
        <header className={styles.header}>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div className={styles.avatar} aria-hidden>
              {/* initial letter */}
              <span style={{ fontSize: 20, fontWeight: 700 }}>
                {displayName && typeof displayName === "string" ? displayName.charAt(0).toUpperCase() : "U"}
              </span>
            </div>
            <div>
              <h1 className={styles.h1}>{t("profile_title", lang)}</h1>
              <div className={styles["muted-ctx"]}>
                {loading ? t("loading", lang) : profile ? displayName : error ?? t("profile_not_found", lang)}
              </div>
            </div>
          </div>

          <div style={{ marginLeft: "auto" }}>
            {isOwner && (
              <button
                className={`${styles.btn} ${styles["btn-primary"]}`}
                onClick={() => {
                  // navigate to edit page if you have one; keep no-op for now but present action
                  // consumer may wire navigation later
                  // eslint-disable-next-line no-console
                  console.log("edit profile clicked");
                }}
              >
                {t("edit_profile", lang)}
              </button>
            )}
          </div>
        </header>

        <main className={styles.main}>
          {loading ? (
            <div className={styles["muted-ctx"]}>{t("loading", lang)}</div>
          ) : error ? (
            <div role="alert" className={styles["muted-ctx"]} style={{ color: "var(--danger)" }}>
              {error}
            </div>
          ) : !profile ? (
            <div className={styles["muted-ctx"]}>{t("profile_not_found", lang)}</div>
          ) : (
            <div className={styles.grid}>
              <section className={styles.column}>
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>{t("profile_info", lang)}</h3>

                <div style={{ marginTop: 12 }}>
                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("name_label", lang)}:</strong> <span style={{ marginLeft: 8 }}>{displayName}</span>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("username_label", lang)}:</strong>{" "}
                    <span style={{ marginLeft: 8 }}>{profile.auth_uid ? profile.auth_uid : "—"}</span>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("role_label", lang)}:</strong>{" "}
                    <span style={{ marginLeft: 8 }}>{profile.role ?? "—"}</span>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("joined", lang)}:</strong>{" "}
                    <span style={{ marginLeft: 8 }}>
                      {profile.created_at ? new Date(profile.created_at).toLocaleString() : "—"}
                    </span>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("followers_label", lang)}:</strong>{" "}
                    <span style={{ marginLeft: 8 }}>{profile.follower_count != null ? profile.follower_count.toLocaleString() : "—"}</span>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("pricing_label", lang)}:</strong>{" "}
                    <span style={{ marginLeft: 8 }}>{profile.pricing_range ?? "—"}</span>
                  </div>

                  <div style={{ marginBottom: 8 }}>
                    <strong>{t("budget_label", lang)}:</strong>{" "}
                    <span style={{ marginLeft: 8 }}>{profile.budget_range ?? "—"}</span>
                  </div>
                </div>
              </section>

              <section className={styles.column}>
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>{t("bio_label", lang)}</h3>
                <div style={{ marginTop: 12 }}>
                  {/* we don't have a dedicated bio field in schema; attempt to show industries/pricing as surrogate */}
                  <div className={styles["muted-ctx"]}>
                    {Array.isArray(profile.industries) && profile.industries.length > 0 ? profile.industries.join(", ") : t("no_bio", lang)}
                  </div>

                  <div style={{ marginTop: 12 }}>
                    <h4 style={{ margin: 0, fontSize: 14, fontWeight: 700 }}>{t("platforms_label", lang)}</h4>
                    <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {platformsList.length === 0 ? (
                        <div className={styles["muted-ctx"]}>{t("no_socials", lang)}</div>
                      ) : (
                        platformsList.map((p: any, i: number) => {
                          // try to render a readable label; platform entries may be strings or objects
                          const label =
                            typeof p === "string"
                              ? p
                              : p.handle
                              ? `${p.platform ?? "acct"} • ${p.handle}`
                              : p.platform
                              ? `${p.platform} • ${p.username ?? p.handle ?? ""}`
                              : JSON.stringify(p);
                          const url = (typeof p === "object" && (p.url || p.link)) ?? null;
                          return url ? (
                            <a key={i} className={styles.badge} href={url} target="_blank" rel="noreferrer" title={label}>
                              {label}
                            </a>
                          ) : (
                            <span key={i} className={styles.badge} title={label} aria-hidden>
                              {label}
                            </span>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}
        </main>
      </div>
    </div>
  
</div>);
}
