// src/components/Wallet.tsx

import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import styles from "./wallet-ui.module.css"; // CSS Module (converted from wallet-ui.css)
import { t } from "../i18n/index";
/**
 * Wallet component
 * - Shows user's points balance
 * - Shows transaction history derived from campaign_submissions (joined with ad_requests)
 * - Withdraw button is present but intentionally a no-op (you will wire payments later)
 *
 * Notes:
 * - Uses session.user.id (UUID) as user UID
 * - Prefers user_points.balance; if absent, sums paid submissions
 * - Subscriptions refresh data in realtime for the signed-in user
 */

type SubmissionRow = {
  id: number;
  campaign_id: number;
  creator_id: string | null;
  submission_link: string | null;
  status: string | null;
  submitted_at: string | null;
  approved_at: string | null;
  payout_amount: string | number | null;
  auto_paid: boolean | null;
  ad_requests?: {
    id?: number;
    title?: string | null;
    reward_per_post?: string | number | null;
  } | null;
};

type Tx = {
  id: number;
  campaignTitle: string;
  amount: number;
  date: string | null;
  note?: string;
};

const parseNumeric = (v: string | number | null | undefined): number => {
  if (v === null || v === undefined) return 0;
  if (typeof v === "number") return v;
  const sanitized = String(v).replace(/,/g, "");
  const n = Number(sanitized);
  return Number.isFinite(n) ? n : 0;
};

type WalletProps = {
  lang: string;
};

export default function Wallet ({ lang }: WalletProps) {
  const [userUid, setUserUid] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [transactions, setTransactions] = useState<Tx[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Load session UID
  const fetchSessionUid = async (): Promise<string | null> => {
    try {
      const { data } = await supabase.auth.getSession();
      const uid = (data as any)?.session?.user?.id ?? null;
      setUserUid(uid);
      return uid;
    } catch (err) {
      console.error("fetchSessionUid error", err);
      setUserUid(null);
      return null;
    }
  };

  // Fetch user_points row (if exists)
  const fetchUserPoints = async (uid: string | null): Promise<number | null> => {
    if (!uid) return null;
    try {
      const { data, error } = await supabase.from("user_points").select("balance").eq("user_id", uid).single();
      if (error && !(error as any).message?.toLowerCase().includes("no rows")) {
        // If an unexpected error occurred, surface it but keep proceeding
        console.warn("user_points fetch warning:", error);
      }
      const bal = data?.balance !== undefined && data?.balance !== null ? parseNumeric(data.balance) : null;
      setBalance(bal);
      return bal;
    } catch (err) {
      console.error("fetchUserPoints error", err);
      setBalance(null);
      return null;
    }
  };

  // Fetch paid submissions for user and map to transactions
  const fetchTransactionsFromSubmissions = async (uid: string | null): Promise<Tx[]> => {
    if (!uid) {
      setTransactions([]);
      return [];
    }
    try {
      // select submissions for this creator that are paid (approved OR auto_paid true)
      // Include ad_requests fields for title and fallback reward_per_post
      const { data, error } = await supabase
        .from("campaign_submissions")
        .select(
          "id,campaign_id,creator_id,submission_link,status,submitted_at,approved_at,payout_amount,auto_paid,ad_requests(id,title,reward_per_post)"
        )
        .eq("creator_id", uid)
        .or("status.eq.approved,auto_paid.eq.true")
        .order("approved_at", { ascending: false })
        .limit(500);

      if (error) throw error;
      const subs = (data as SubmissionRow[]) ?? [];

      const txs: Tx[] = subs.map((s) => {
        const payout = parseNumeric(s.payout_amount ?? s.ad_requests?.reward_per_post ?? 0);
        const title = s.ad_requests?.title ?? `Campaign #${s.campaign_id}`;
        const date = s.approved_at ?? s.submitted_at ?? null;
        const note =
          s.status === "approved"
            ? t("approved", lang)
            : s.auto_paid
            ? t("auto_paid", lang)
            : s.status ?? undefined;
        return {
          id: s.id,
          campaignTitle: title,
          amount: payout,
          date,
          note,
        };
      });

      // sort by date desc
      txs.sort((a, b) => {
        const ta = a.date ? Date.parse(a.date) : 0;
        const tb = b.date ? Date.parse(b.date) : 0;
        return tb - ta;
      });

      setTransactions(txs);
      return txs;
    } catch (err) {
      console.error("fetchTransactionsFromSubmissions err", err);
      setTransactions([]);
      return [];
    }
  };

  const reconcileBalance = (userPointsBalance: number | null, txs: Tx[]) => {
    if (userPointsBalance !== null) {
      setBalance(userPointsBalance);
      return userPointsBalance;
    }
    const sum = txs.reduce((acc, t) => acc + (t.amount || 0), 0);
    setBalance(sum);
    return sum;
  };

  // Load all data
  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const uid = await fetchSessionUid();
      if (!uid) {
        setError(t("not_signed_in", lang));
        setLoading(false);
        return;
      }
      const [userPointsBal, txs] = await Promise.all([fetchUserPoints(uid), fetchTransactionsFromSubmissions(uid)]);
      reconcileBalance(userPointsBal, txs);
    } catch (err: any) {
      console.error("Wallet load error", err);
      setError(err?.message ?? String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();

    // Set up realtime subscriptions (lightweight)
    let submissionsChannel: any = null;
    let pointsChannel: any = null;

    (async () => {
      const { data } = await supabase.auth.getSession();
      const uid = (data as any)?.session?.user?.id ?? null;
      if (!uid) return;

      // Subscribe to changes on campaign_submissions for this user
      submissionsChannel = supabase
        .channel(`realtime:campaign_submissions:${uid}`)
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "campaign_submissions", filter: `creator_id=eq.${uid}` },
          () => {
            fetchTransactionsFromSubmissions(uid).then((txs) => reconcileBalance(null, txs));
            // Also refresh user_points
            fetchUserPoints(uid);
          }
        )
        .subscribe();

      // Subscribe to user_points changes for this user
      pointsChannel = supabase
        .channel(`realtime:user_points:${uid}`)
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "user_points", filter: `user_id=eq.${uid}` },
          () => {
            fetchUserPoints(uid);
          }
        )
        .subscribe();
    })();

    return () => {
      if (submissionsChannel) supabase.removeChannel(submissionsChannel);
      if (pointsChannel) supabase.removeChannel(pointsChannel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Render
  return (
    <div className={styles.container}>
      {/* we use a lot of classes from the module to implement the full UI layer */}
      <div className={styles.content}>
        <h1 className={styles.h1}>{t("wallet_title", lang)}</h1>
        <p className={styles.lead}>{t("wallet_lead", lang)}</p>

        <div className={styles["wallet-card"]} style={{ marginTop: 24 }}>
          <div className={styles.left}>
            <div className={styles.meta}>{t("total_points", lang)}</div>
            <div className={styles.points} aria-live="polite">
              {loading ? t("loading_short", lang) : balance !== null ? balance.toLocaleString() : "0"}
            </div>
            {/* show account uid short */}
            {userUid && <div className={styles["muted-ctx"]} style={{ marginTop: 8 }}>{t("account", lang)}: {userUid.slice(0, 8)}</div>}
          </div>

          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div className={styles.icon} aria-hidden>
              {/* decorative coin svg (kept inline so no additional classes are needed) */}
              <svg width="40" height="40" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M216 72H56a8 8 0 0 1 0-16H192a8 8 0 0 0 0-16H56A24 24 0 0 0 32 64V192a24 24 0 0 0 24 24H216a16 16 0 0 0 16-16V88a16 16 0 0 0-16-16Z" fill="white" opacity="0.5"/>
              </svg>
            </div>

            <button className={`${styles.btn} ${styles["btn-primary"]} ${styles["btn-sm"]}`} onClick={() => { /* no-op: implement payments later */ }}>
              {t("withdraw", lang)}
            </button>
          </div>
        </div>

        <div className={styles["table-card"]} style={{ marginTop: 28 }}>
          <div className={styles["table-head"]} role="heading" aria-level={2}>
            <div className={`${styles["col-date"]} ${styles["table-head-text"]}`}>{t("date", lang)}</div>
            <div className={`${styles["col-desc"]} ${styles["table-head-text"]}`}>{t("description", lang)}</div>
            <div className={`${styles["col-points"]} ${styles["table-head-text"]}`}>{t("points", lang)}</div>
          </div>

          <div className={styles["table-body"]} aria-live="polite">
            {loading ? (
              <div className={`${styles["table-row"]} ${styles["muted-ctx"]}`}>{t("loading_transactions", lang)}</div>
            ) : error ? (
              <div className={`${styles["table-row"]}`} style={{ color: "var(--danger)" }}>{error}</div>
            ) : transactions.length === 0 ? (
              <div className={`${styles["table-row"]} ${styles["muted-ctx"]}`}>{t("no_transactions", lang)}</div>
            ) : (
              transactions.map((tItem) => (
                <div key={tItem.id} className={styles["table-row"]} role="article" aria-label={`${t("transaction_for", lang)} ${tItem.campaignTitle}`}>
                  <div className={styles["col-date"]}>{tItem.date ? new Date(tItem.date).toLocaleString() : "—"}</div>
                  <div className={styles["col-desc"]}>
                    {tItem.campaignTitle}
                    {tItem.note ? <span style={{ marginLeft: 8, color: "var(--muted)", fontSize: 12 }}>· {tItem.note}</span> : null}
                  </div>
                  <div className={`${styles["col-points"]} ${tItem.amount >= 0 ? styles.positive : styles.negative}`}>
                    {tItem.amount >= 0 ? `+${tItem.amount.toLocaleString()}` : `${tItem.amount.toLocaleString()}`}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* small footer area using available helpers */}
        <div style={{ marginTop: 18 }} className={`${styles["muted-ctx"]}`}>
          {t("wallet_tip", lang)}
        </div>
      </div>
    </div>
  );
};


