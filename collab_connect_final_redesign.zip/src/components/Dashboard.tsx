import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { supabase } from "../lib/supabaseClient"
import { t } from "../i18n/index"
import LoadingScreen from "../components/LoadingScreen"

type DashboardProps = {
  session: any
  lang: string
}

export default function Dashboard({ session, lang }: DashboardProps) {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [role, setRole] = useState<string | null>(null)

  useEffect(() => {
    const checkProfile = async () => {
      if (!session?.user) {
        navigate("/login")
        return
      }

      const { data: profile, error } = await supabase
        .from("profiles")
        .select("role")
        .eq("auth_uid", session.user.id)
        .single()

      if (error) {
        console.error("Error fetching profile:", error.message)
        setRole(null)
      } else {
        setRole(profile?.role || null)

        // Redirect automatically if role exists
        if (profile?.role === "brand") navigate("/brand-dashboard")
        else if (profile?.role === "influencer") navigate("/influencer-dashboard")
      }

      setLoading(false)
    }

    checkProfile()
  }, [session, navigate])

  if (loading) return <LoadingScreen/>

  // If user has no role saved yet
  return (
    <div className="neon-card">
<div style={{ textAlign: "center", padding: "2rem" }}>
      <h2>{t("noRoleTitle", lang)}</h2>
      <p>{t("noRoleMessage", lang)}</p>
      <button
        style={{
          backgroundColor: "#4F46E5",
          color: "white",
          padding: "0.8rem 1.5rem",
          borderRadius: "8px",
          marginTop: "1rem",
          cursor: "pointer",
        }}
        onClick={() => navigate("/role-selection")}
      >
        {t("chooseRole", lang)}
      </button>
    </div>
  )
}
