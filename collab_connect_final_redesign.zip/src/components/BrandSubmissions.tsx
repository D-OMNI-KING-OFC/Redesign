import React, { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import styles from "./campaigns-ui.module.css";
import { t } from "../i18n/index";

type AdRequest = {
  id?: number;
  title?: string | null;
  reward_per_post?: string | number | null;
  advertiser_id?: string | null;
};

type Submission = {
  id: number;
  campaign_id: number;
  creator_id: string | null;
  submission_link: string | null;
  status: "pending" | "approved" | "revision_requested" | "auto_paid" | "rejected" | string;
  submitted_at: string | null;
  approved_at?: string | null;
  revision_requested_at?: string | null;
  payout_amount?: string | number | null;
  auto_paid?: boolean | null;
  ad_requests?: AdRequest | null;
};
 
type bdprops = {
  lang: string
}

export default function BrandSubmissions({lang}: bdprops): React.ReactElement {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [processingIds, setProcessingIds] = useState<Record<number, boolean>>({});
  const [userId, setUserId] = useState<string | null>(null);

  // Helper: fetch current session user id and set it
  const loadSessionUser = async () => {
    try {
      const sessionResp = await supabase.auth.getSession();
      const session = sessionResp?.data?.session;
      const id = session?.user?.id ?? null;
      setUserId(id);
      return id;
    } catch (err) {
      console.error("loadSessionUser error:", err);
      setUserId(null);
      return null;
    }
  };

  // Fetch submissions where the current user is the advertiser for the ad_request.
  const fetchSubmissions = async () => {
    setLoading(true);
    setGeneralError(null);

    try {
      const id = await loadSessionUser();

      if (!id) {
        setSubmissions([]);
        setGeneralError(t("must_be_signed_in_to_view_submissions", lang));
        return;
      }

      // Force an inner join so only rows that belong to this advertiser come back
      const resp = await supabase
        .from("campaign_submissions")
        .select("*, ad_requests!inner(id,title,reward_per_post,advertiser_id)")
        .eq("ad_requests.advertiser_id", id)
        .order("submitted_at", { ascending: true })
        .limit(1000);

      if (resp.error) throw resp.error;
      const data = (resp.data as any) as Submission[];
      setSubmissions(data ?? []);
    } catch (err: any) {
      console.error("fetchSubmissions error:", err);
      setGeneralError(err?.message ?? String(err));
      setSubmissions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();

    // subscribe to changes to keep UI fresh
    const channel: any = supabase
      .channel("public:campaign_submissions")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "campaign_submissions" },
        () => {
          fetchSubmissions();
        }
      )
      .subscribe();

    return () => {
      // remove subscription
      try {
        // newer supabase libs use channel.unsubscribe(); older ones use removeChannel
        if (channel?.unsubscribe) channel.unsubscribe();
        else supabase.removeChannel?.(channel);
      } catch (e) {
        // ignore
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Approve submission -> call RPC approve_submission with param p_submission_id
  const approveSubmission = async (submissionId: number, adRequestOwnerId?: string | null) => {
    if (!window.confirm(t("confirm_approve_submission", lang))) {
      return;
    }

    // extra guard: ensure current user is owner
    if (!userId || userId !== adRequestOwnerId) {
      setGeneralError(t("not_authorized_to_approve", lang));
      return;
    }

    setProcessingIds((p) => ({ ...p, [submissionId]: true }));
    setGeneralError(null);

    try {
      // RPC param name is p_submission_id per DB function signature
      const { data, error } = await supabase.rpc("approve_submission", { p_submission_id: submissionId });

      if (error) throw error;

      await fetchSubmissions();
      alert(t("submission_approved_and_paid", lang));
    } catch (err: any) {
      console.error("approveSubmission error:", err);
      setGeneralError(err?.message ?? String(err));
    } finally {
      setProcessingIds((p) => ({ ...p, [submissionId]: false }));
    }
  };

  // Request revision -> call DB RPC directly (no Edge function)
  const requestRevision = async (submission: Submission) => {
    if (!window.confirm(t("confirm_request_revision", lang))) return;

    // guard: only advertiser can request
    if (!userId || userId !== submission.ad_requests?.advertiser_id) {
      setGeneralError(t("not_authorized_to_request_revision", lang));
      return;
    }

    setProcessingIds((p) => ({ ...p, [submission.id]: true }));
    setGeneralError(null);

    try {
      const { error } = await supabase.rpc("request_revision_for_submission", { p_submission_id: submission.id });
      if (error) throw error;

      await fetchSubmissions();
      alert(t("revision_requested_informed", lang));
    } catch (err: any) {
      console.error("requestRevision error:", err);
      setGeneralError(err?.message ?? String(err));
    } finally {
      setProcessingIds((p) => ({ ...p, [submission.id]: false }));
    }
  };

  // Reject submission -> call RPC rpc_reject_campaign_submission
  const rejectSubmission = async (submission: Submission) => {
    if (!window.confirm(t("confirm_reject_submission", lang))) return;

    if (!userId || userId !== submission.ad_requests?.advertiser_id) {
      setGeneralError(t("not_authorized_to_reject", lang));
      return;
    }

    setProcessingIds((p) => ({ ...p, [submission.id]: true }));
    setGeneralError(null);

    try {
      // DB function name is rpc_reject_campaign_submission
      const { data, error } = await supabase.rpc("rpc_reject_campaign_submission", { p_submission_id: submission.id });

      if (error) throw error;

      await fetchSubmissions();
      alert(t("submission_rejected_and_slot_reopened", lang));
    } catch (err: any) {
      console.error("rejectSubmission error:", err);
      setGeneralError(err?.message ?? String(err));
    } finally {
      setProcessingIds((p) => ({ ...p, [submission.id]: false }));
    }
  };

  // Handles timers (revision expiry and 7-day auto payout) - triggers server RPCs if they expire
  const processTimers = async (submission: Submission) => {
    try {
      const now = new Date();

      // 48h revision expiry
      if (submission.status === "revision_requested" && submission.revision_requested_at) {
        const expiry = new Date(submission.revision_requested_at);
        expiry.setHours(expiry.getHours() + 48);
        if (now >= expiry) {
          // call server-side helper to mark rejected and free slot
          const { error } = await supabase.rpc("_reject_submission_if_not_updated", { p_submission_id: submission.id });
          if (error) console.warn("handle_revision_expiry warning:", error);
          else await fetchSubmissions();
        }
      }

      // 7-day auto payout for pending submissions
      if (submission.status === "pending" && submission.submitted_at) {
        const expiry = new Date(submission.submitted_at);
        expiry.setDate(expiry.getDate() + 7);
        if (now >= expiry) {
          const { error } = await supabase.rpc("auto_payout_submission", { p_submission_id: submission.id });
          if (error) console.warn("auto_payout_submission warning:", error);
          else await fetchSubmissions();
        }
      }
    } catch (err: any) {
      console.error("processTimers error:", err);
    }
  };

  // timer tick to check expiries
  const [nowTick, setNowTick] = useState<number>(Date.now());
  useEffect(() => {
    const interval = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!submissions || submissions.length === 0) return;
    submissions.forEach((s) => {
      processTimers(s);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nowTick, submissions]);

  const getTimerMs = (submission: Submission): number => {
    const nowDate = new Date();
    if (submission.status === "revision_requested" && submission.revision_requested_at) {
      const expiry = new Date(submission.revision_requested_at);
      expiry.setHours(expiry.getHours() + 48);
      return Math.max(expiry.getTime() - nowDate.getTime(), 0);
    }
    if (submission.status === "pending" && submission.submitted_at) {
      const expiry = new Date(submission.submitted_at);
      expiry.setDate(expiry.getDate() + 7);
      return Math.max(expiry.getTime() - nowDate.getTime(), 0);
    }
    return 0;
  };

  const formatTimer = (ms: number) => {
    if (ms <= 0) return t("expired", lang);
    const totalSec = Math.floor(ms / 1000);
    const d = Math.floor(totalSec / (3600 * 24));
    const h = Math.floor((totalSec % (3600 * 24)) / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    // keep the compact numeric formatting; units remain as single letters for now
    return `${d}d ${h}h ${m}m ${s}s`;
  };

  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <h2 className={styles["page-header"]}>{t("brand_submissions", lang)}</h2>
      </header>

      {generalError && (
        <div className={styles["muted"]} role="alert">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span>{generalError}</span>
            <button
              onClick={() => setGeneralError(null)}
              aria-label={t("dismiss_error", lang)}
              style={{ marginLeft: 12, cursor: "pointer" }}
            >
              {t("dismiss", lang)}
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className={styles["muted-ctx"]}>{t("loading_submissions", lang)}</div>
      ) : submissions.length === 0 ? (
        <div className={styles["muted-ctx"]}>{t("no_submissions_yet", lang)}</div>
      ) : (
        <div className={styles["table-wrapper"]}>
          <table className="table-neon">
            <thead>
              <tr>
                <th className={styles["font-medium"]}>{t("campaign_id", lang)}</th>
                <th className={styles["font-medium"]}>{t("campaign", lang)}</th>
                <th className={styles["font-medium"]}>{t("creator_id", lang)}</th>
                <th className={styles["font-medium"]}>{t("status", lang)}</th>
                <th className={styles["font-medium"]}>{t("link", lang)}</th>
                <th className={styles["font-medium"]}>{t("timer", lang)}</th>
                <th className={styles["font-medium"]}>{t("actions", lang)}</th>
              </tr>
            </thead>
            <tbody>
              {submissions.map((s) => {
                const remainingMs = getTimerMs(s);
                const isRevisionExpired = s.status === "revision_requested" && remainingMs <= 0;
                const isAutoPay = s.status === "pending" && remainingMs <= 0;
                const isProcessing = !!processingIds[s.id];

                const badgeClass =
                  s.status === "approved"
                    ? `${styles.badge} ${styles["badge--active"]}`
                    : s.status === "revision_requested"
                    ? `${styles.badge} ${styles["badge--warning"]}`
                    : s.status === "auto_paid"
                    ? `${styles.badge} ${styles["badge--completed"]}`
                    : s.status === "rejected"
                    ? `${styles.badge} ${styles["badge--danger"] || styles["badge--completed"]}`
                    : `${styles.badge} ${styles["badge--pending"]}`;

                const ownerId = s.ad_requests?.advertiser_id ?? null;
                const showActions = !!userId && userId === ownerId;

                // display status label (translated)
                const displayStatus = isAutoPay ? t("auto_paid", lang) : t(String(s.status ?? ""), lang);

                return (
                  <tr key={s.id} className={isRevisionExpired ? styles["row-expired"] : ""}>
                    <td className={styles["td"]}>{s.campaign_id}</td>
                    <td className={styles["td"]}>{s.ad_requests?.title ?? "—"}</td>
                    <td className={styles["td"]}>{s.creator_id ?? "—"}</td>
                    <td className={styles["td"]}>
                      <span className={badgeClass}>{displayStatus}</span>
                    </td>
                    <td className={styles["td"]}>
                      {s.submission_link ? (
                        <a href={s.submission_link} target="_blank" rel="noreferrer" className={styles["action"]}>
                          {t("view", lang)}
                        </a>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className={styles["td"]}>{remainingMs > 0 ? formatTimer(remainingMs) : t("expired", lang)}</td>

                    <td className={styles["form-actions"]}>
                      {/* Only show actions to the campaign advertiser */}
                      {showActions && s.status === "pending" && remainingMs > 0 && (
                        <>
                          <button
                            className={styles["btn-primary"]}
                            onClick={() => approveSubmission(s.id, ownerId)}
                            disabled={isProcessing}
                            aria-disabled={isProcessing}
                          >
                            {isProcessing ? t("processing", lang) : t("approve", lang)}
                          </button>

                          <button
                            className={styles["btn-ghost"]}
                            onClick={() => requestRevision(s)}
                            disabled={isProcessing}
                            aria-disabled={isProcessing}
                          >
                            {t("request_revision", lang)}
                          </button>

                          <button
                            className={styles["btn-ghost"]}
                            onClick={() => rejectSubmission(s)}
                            disabled={isProcessing}
                            aria-disabled={isProcessing}
                            title={t("reject_submission_title", lang)}
                          >
                            {t("reject", lang)}
                          </button>
                        </>
                      )}

                      {/* Revision requested */}
                      {!showActions && s.status === "revision_requested" && remainingMs > 0 && (
                        <span className={styles["muted-ctx"]}>
                          {t("awaiting_revision", lang)} ({formatTimer(remainingMs)})
                        </span>
                      )}

                      {/* Expired / Auto actions */}
                      {(isRevisionExpired || isAutoPay) && (
                        <span className={styles["muted-ctx"]}>{t("no_action_timer_expired", lang)}</span>
                      )}

                      {/* Approved / Auto-paid / Rejected */}
                      {(s.status === "approved" || s.status === "auto_paid" || s.status === "rejected") && (
                        <span className={styles["muted-ctx"]}>{t(String(s.status), lang)}</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
