// src/pages/BrandDashboard.tsx
import React, { useEffect, useRef, useState } from "react";
import resp from "./DashboardResponsive.module.css";
import { supabase } from "../lib/supabaseClient";
import Wallet from "../components/Wallet";
import ViewActiveCampaigns from "../components/ViewActiveCampaigns";
import BrandSubmissions from "../components/BrandSubmissions";
import MTSV2 from "../pages/MTSV2";
import CampaignCreation from "../components/CampaignCreation";
import { t } from "../i18n/index";
import Profiles from "../components/Profiles";

type ActivityItem = { id: string; type: "points" | "submission"; text: string; ts: string };

type DashboardProps = {
  lang: string;
  session?: any;
};

type TabKey =
  | "home"
  | "wallet"
  | "activeCampaigns"
  | "brandSubmissions"
  | "influencerSearch"
  | "campaignCreation"
  | "profile";

const NavItem: React.FC<{
  active: boolean;
  onClick: () => void;
  label: string;
  icon?: React.ReactNode;
  collapsed?: boolean;
}> = ({ active, onClick, label, icon, collapsed }) => {
  const leftAccentGradient = `radial-gradient(
      circle at 26% 20%,
      rgba(0, 110, 255, 0.95) 0%,
      rgba(0, 110, 255, 0.60) 12%,
      rgba(0, 110, 255, 0.18) 28%,
      transparent 44%
    ),
    radial-gradient(
      circle at 74% 78%,
      rgba(8, 90, 255, 0.85) 0%,
      rgba(8, 90, 255, 0.45) 14%,
      rgba(8, 90, 255, 0.08) 32%,
      transparent 50%
    ),
    linear-gradient(120deg,
      rgba(2,36,102,0.8) 0%,
      rgba(1,56,150,0.45) 20%,
      rgba(1,56,150,0.20) 40%,
      transparent 55%
    )`;

  return (
    <div className="neon-card">
<button
      onClick={onClick}
      className={`${resp.navItem ?? ""} navItem ${active ? "navItemActive " + (resp.navItemActive ?? "") : ""} ${
        collapsed ? "navItemIconOnly" : ""
      }`}
      style={{
        position: "relative",
        overflow: "hidden",
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 12px",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        textAlign: "left",
      }}
      aria-pressed={active}
    >
      <span
        aria-hidden
        style={{
          position: "absolute",
          left: 0,
          top: 6,
          bottom: 6,
          width: active ? 6 : 4,
          borderTopRightRadius: 6,
          borderBottomRightRadius: 6,
          backgroundImage: leftAccentGradient,
          backgroundSize: "cover",
          transform: `translateX(${active ? "0" : "-2px"})`,
          transition: "all 200ms ease",
        }}
      />
      <span style={{ marginLeft: 12, display: "inline-flex", gap: 12, alignItems: "center" }}>
        {icon}
        <span style={{ fontWeight: 600, display: collapsed ? "none" : "inline" }}>{label}</span>
      </span>
    </button>
  );
};

export default function BrandDashboard({ lang }: DashboardProps) {
  // tabs + nav state
  const [tab, setTab] = useState<TabKey>("home");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // device/responsive detection
  const [isMobile, setIsMobile] = useState<boolean>(false);

  // Dashboard state
  const [userUid, setUserUid] = useState<string | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState<boolean>(false);
  const [earnings, setEarnings] = useState<number>(0);
  const [activeCampaignsCount, setActiveCampaignsCount] = useState<number>(0);
  const [pendingApprovalsCount, setPendingApprovalsCount] = useState<number>(0);
  const [recentActivity, setRecentActivity] = useState<ActivityItem[]>([]);

  // Responsive scale & collapse logic
  const MIN_SCALE = 0.75;
  const REF_WIDTH = 1200;
  const [viewScale, setViewScale] = useState<number>(1);
  const resizeTimerRef = useRef<number | null>(null);
  const computeScaleFromVW = (vw: number) => Math.max(MIN_SCALE, Math.min(1, vw / REF_WIDTH));

  useEffect(() => {
    if (typeof window === "undefined") return;
    const applyScale = () => {
      setViewScale(computeScaleFromVW(window.innerWidth));
      setIsMobile(window.innerWidth < 769);
    };
    applyScale();
    const onResize = () => {
      if (resizeTimerRef.current) window.clearTimeout(resizeTimerRef.current);
      resizeTimerRef.current = window.setTimeout(() => {
        applyScale();
        resizeTimerRef.current = null;
      }, 120) as unknown as number;
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (resizeTimerRef.current) window.clearTimeout(resizeTimerRef.current);
    };
  }, []);

  const collapsed = viewScale < 0.82;
  const setSafeViewScale = (v: number) => setViewScale(Math.max(0.6, Math.min(1.05, v)));
  const toggleMobileNav = () => {
    // if mobile -> show slide nav; if desktop -> toggle collapse visually (keeps behavior intuitive)
    if (isMobile) {
      setMobileNavOpen((s) => !s);
    } else {
      // on desktop clicking "menu" should toggle a compact sidebar (optional)
      // to keep things simple, on desktop we'll toggle a small 'mobileNavOpen' state to allow manual override of main width
      setMobileNavOpen((s) => !s);
      // but keep mobileNavOpen meaning "sidebar narrower" on desktop; the rendering below handles both cases
    }
  };

  const primaryGradient = `radial-gradient(
      circle at 26% 20%,
      rgba(0, 110, 255, 0.95) 0%,
      rgba(0, 110, 255, 0.60) 12%,
      rgba(0, 110, 255, 0.18) 28%,
      transparent 44%
    ),
    radial-gradient(
      circle at 74% 78%,
      rgba(8, 90, 255, 0.85) 0%,
      rgba(8, 90, 255, 0.45) 14%,
      rgba(8, 90, 255, 0.08) 32%,
      transparent 50%
    ),
    linear-gradient(120deg,
      rgba(2,36,102,0.8) 0%,
      rgba(1,56,150,0.45) 20%,
      rgba(1,56,150,0.20) 40%,
      transparent 55%
    )`;

  // keep this accent gradient as you requested
  const accentGradient = `linear-gradient(135deg, #a21caf 0%, #ec4899 40%, #fb923c 100%)`;

  // util
  const formatCurrency = (n: number) => (n >= 0 ? `₦ ${n.toLocaleString(undefined, { maximumFractionDigits: 0 })}` : `₦ 0`);

  // fetch dashboard data
  const fetchDashboardData = async (maybeUid?: string | null) => {
    setDashboardLoading(true);
    try {
      let uid = maybeUid ?? userUid;
      if (!uid) {
        const { data } = await supabase.auth.getSession();
        uid = (data as any)?.session?.user?.id ?? null;
        if (uid) setUserUid(uid);
      }
      if (!uid) {
        setEarnings(0);
        setActiveCampaignsCount(0);
        setPendingApprovalsCount(0);
        setRecentActivity([]);
        return;
      }

      // parallel queries
      const pPoints = supabase.from("user_points").select("balance").eq("user_id", uid).limit(1);
      const pMyAdRequests = supabase.from("ad_requests").select("id,status,remaining_slots").eq("advertiser_id", uid).limit(500);
      const pAvailable = supabase.from("ad_requests").select("id").gt("remaining_slots", 0).limit(500);
      const pMyPendingSubmissions = supabase
        .from("campaign_submissions")
        .select("id, campaign_id, status, submitted_at")
        .eq("creator_id", uid)
        .eq("status", "pending")
        .limit(500);
      const pPointsTx = supabase
        .from("points_transactions")
        .select("id, amount, reason, created_at")
        .eq("user_id", uid)
        .order("created_at", { ascending: false })
        .limit(6);

      const [rPoints, rMyAdRequests, rAvailable, rMyPendingSub, rPointsTx] = await Promise.all([
        pPoints,
        pMyAdRequests,
        pAvailable,
        pMyPendingSubmissions,
        pPointsTx,
      ]);

      if (rPoints.error) {
        console.debug("user_points fetch error:", rPoints.error);
        setEarnings(0);
      } else {
        const b = (rPoints.data && (rPoints.data as any)[0]?.balance) ?? null;
        if (b !== null && b !== undefined) {
          const val = Number(b);
          setEarnings(isNaN(val) ? 0 : val);
        } else {
          if (!rPointsTx.error) {
            const sum = (rPointsTx.data ?? []).reduce((acc: number, t: any) => acc + Number(t.amount ?? 0), 0);
            setEarnings(sum);
          } else {
            setEarnings(0);
          }
        }
      }

      // advertiser vs creator
      let isAdvertiser = false;
      let myAdRequestIds: number[] = [];
      if (!rMyAdRequests.error && Array.isArray(rMyAdRequests.data)) {
        const reqs = rMyAdRequests.data as Array<any>;
        if (reqs.length > 0) {
          isAdvertiser = true;
          myAdRequestIds = reqs.map((r) => r.id).filter(Boolean);
        }
      }

      if (isAdvertiser) {
        const activeCount = (rMyAdRequests.data ?? []).filter((ar: any) => ar.status === "active" || ar.status === "pending").length;
        setActiveCampaignsCount(activeCount);

        if (myAdRequestIds.length > 0) {
          const { data: subsToMe, error: subsErr } = await supabase
            .from("campaign_submissions")
            .select("id")
            .in("campaign_id", myAdRequestIds)
            .eq("status", "pending")
            .limit(1000);
          if (subsErr) {
            console.debug("subsToMe err", subsErr);
            setPendingApprovalsCount(0);
          } else {
            setPendingApprovalsCount((subsToMe ?? []).length);
          }
        } else {
          setPendingApprovalsCount(0);
        }
      } else {
        if (!rAvailable.error) setActiveCampaignsCount((rAvailable.data ?? []).length);
        else setActiveCampaignsCount(0);

        if (!rMyPendingSub.error) setPendingApprovalsCount((rMyPendingSub.data ?? []).length);
        else setPendingApprovalsCount(0);
      }

      // recent activity
      const { data: recentSubs, error: recentSubsErr } = await supabase
        .from("campaign_submissions")
        .select("id, campaign_id, status, submitted_at")
        .eq("creator_id", uid)
        .order("submitted_at", { ascending: false })
        .limit(6);

      const activities: ActivityItem[] = [];

      if (!rPointsTx.error && Array.isArray(rPointsTx.data)) {
        for (const t of (rPointsTx.data as any[])) {
          activities.push({
            id: `pt-${t.id}`,
            type: "points",
            text: `${t.reason ?? "Points"}: ${Number(t.amount ?? 0) >= 0 ? "+" : ""}${Number(t.amount ?? 0)}`,
            ts: t.created_at ?? new Date().toISOString(),
          });
        }
      }

      if (!recentSubsErr && Array.isArray(recentSubs)) {
        for (const s of (recentSubs as any[])) {
          activities.push({
            id: `sub-${s.id}`,
            type: "submission",
            text: `Submission ${s.id} — status: ${s.status ?? "unknown"}`,
            ts: s.submitted_at ?? new Date().toISOString(),
          });
        }
      }

      activities.sort((a, b) => (a.ts < b.ts ? 1 : a.ts > b.ts ? -1 : 0));
      setRecentActivity(activities.slice(0, 6));
    } catch (err) {
      console.error("fetchDashboardData err", err);
    } finally {
      setDashboardLoading(false);
    }
  };

  // initial load: fetch session uid and immediately load dashboard data
  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      const uid = (data as any)?.session?.user?.id ?? null;
      if (uid) setUserUid(uid);
      await fetchDashboardData(uid);
    })();

    // subscribe to changes that should refresh dashboard counts
    const campaignsSub = supabase
      .channel("public:ad_requests")
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "ad_requests" }, () => fetchDashboardData(userUid))
      .subscribe();

    const subsSub = supabase
      .channel("public:campaign_submissions")
      .on("postgres_changes", { event: "*", schema: "public", table: "campaign_submissions" }, () => fetchDashboardData(userUid))
      .subscribe();

    return () => {
      // best-effort cleanup
      try {
        supabase.removeChannel(campaignsSub);
        supabase.removeChannel(subsSub);
      } catch (e) {
        // ignore if runtime doesn't support removeChannel
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // layout calculations
  const desktopSidebarWidth = collapsed ? 96 : 280;
  const asideWidthPx = isMobile ? 0 : desktopSidebarWidth;
  const mainStyleWidth = isMobile ? "100%" : `calc(100% - ${asideWidthPx}px)`;

  // decorative border style to "match the design"
  const sectionBorder = "1px solid rgba(255,255,255,0.06)";
  const cardBoxShadow = "0 8px 28px rgba(2,6,23,0.45)";

  return (
    <div className={`dashboardWrap ${resp.dashboardWrap ?? ""} landingContainer`} style={{ minHeight: "100vh", position: "relative" }}>
      {/* mobile / compact nav toggle */}
      <button
        onClick={toggleMobileNav}
        className={`${resp.mobileNavToggle ?? ""} mobileNavToggle btn`}
        aria-expanded={mobileNavOpen}
        aria-controls="dashboard-sidebar"
        style={{
          position: "fixed",
          top: 20,
          left: 20,
          zIndex: 1400,
          padding: "10px 12px",
          borderRadius: 10,
          border: "none",
          color: "#fff",
          background: "linear-gradient(90deg, rgba(255,255,255,0.06), rgba(255,255,255,0.03))",
          backdropFilter: "blur(6px)",
          boxShadow: "0 6px 16px rgba(2,6,23,0.45)",
        }}
      >
        {mobileNavOpen ? t("close", lang) : t("menu", lang)}
      </button>

      {/* sidebar */}
      <aside
        id="dashboard-sidebar"
        className={`${resp.sidebar ?? ""} sidebar ${mobileNavOpen ? "sidebarOpen" : ""} ${collapsed ? "sidebarCollapsed" : ""}`}
        aria-hidden={isMobile ? !mobileNavOpen : false}
        style={{
          // mobile: fixed and slide in/out via transform; desktop: relative with width transition
          position: isMobile ? "fixed" : "relative",
          left: 0,
          top: 0,
          bottom: 0,
          width: isMobile ? "70vw" : `${desktopSidebarWidth}px`,
          maxWidth: isMobile ? "85vw" : "320px",
          zIndex: 1350,
          transform: isMobile ? (mobileNavOpen ? "translateX(0)" : "translateX(-110%)") : "translateX(0)",
          transition: "transform 260ms cubic-bezier(.2,.9,.2,1), width 220ms ease",
          willChange: "transform, width",
          boxSizing: "border-box",
          padding: 10,
          // decorative border & glass look
          borderRight: !isMobile ? sectionBorder : undefined,
          boxShadow: !isMobile ? "none" : "0 10px 40px rgba(2,6,23,0.5)",
          background: "transparent",
        }}
      >
        <div style={{ borderRadius: 12, padding: 2, width: "100%", backgroundImage: primaryGradient }}>
          <div
            style={{
              background: "var(--glass, rgba(255,255,255,0.04))",
              borderRadius: 10,
              padding: 18,
              display: "flex",
              flexDirection: "column",
              gap: 12,
              height: "calc(100vh - 36px)",
              overflow: "hidden",
              border: sectionBorder,
              boxShadow: cardBoxShadow,
            }}
          >
            <div style={{ marginBottom: 8 }}>
              <h2 style={{ fontSize: 20, fontWeight: 800, margin: 0, color: "var(--ink-1, #e6eef8)" }}>{t("collabConnect", lang)}</h2>
              <div style={{ color: "var(--primary, #13a4ec)", fontWeight: 700 }}>{t("premium", lang)}</div>
            </div>

            <nav
              className={`${resp.navList ?? ""} navList`}
              style={{
                flexGrow: 1,
                overflowY: "auto",
                paddingRight: 6,
                display: "flex",
                flexDirection: "column",
                gap: 6,
              }}
            >
              <NavItem
                active={tab === "home"}
                onClick={() => {
                  setTab("home");
                  if (isMobile) setMobileNavOpen(false);
                }}
                label={t("dashboard", lang)}
                icon={<span style={{ fontSize: 18 }}>🏠</span>}
                collapsed={collapsed}
              />
              <NavItem
                active={tab === "influencerSearch"}
                onClick={() => {
                  setTab("influencerSearch");
                  if (isMobile) setMobileNavOpen(false);
                }}
                label={t("influencerSearch", lang)}
                icon={<span style={{ fontSize: 18 }}>🔎</span>}
                collapsed={collapsed}
              />
              <NavItem
                active={tab === "campaignCreation"}
                onClick={() => {
                  setTab("campaignCreation");
                  if (isMobile) setMobileNavOpen(false);
                }}
                label={t("campaignCreation", lang)}
                icon={<span style={{ fontSize: 18 }}>➕</span>}
                collapsed={collapsed}
              />
              <NavItem
                active={tab === "activeCampaigns"}
                onClick={() => {
                  setTab("activeCampaigns");
                  if (isMobile) setMobileNavOpen(false);
                }}
                label={t("myCampaigns", lang)}
                icon={<span style={{ fontSize: 18 }}>📣</span>}
                collapsed={collapsed}
              />
              <NavItem
                active={tab === "brandSubmissions"}
                onClick={() => {
                  setTab("brandSubmissions");
                  if (isMobile) setMobileNavOpen(false);
                }}
                label={t("submissions", lang)}
                icon={<span style={{ fontSize: 18 }}>📝</span>}
                collapsed={collapsed}
              />
              <NavItem
                active={tab === "wallet"}
                onClick={() => {
                  setTab("wallet");
                  if (isMobile) setMobileNavOpen(false);
                }}
                label={t("walletTransactions", lang)}
                icon={<span style={{ fontSize: 18 }}>💼</span>}
                collapsed={collapsed}
              />

              <div style={{ marginTop: "auto" }}>
                <NavItem
                  active={tab === "profile"}
                  onClick={() => {
                    setTab("profile");
                    if (isMobile) setMobileNavOpen(false);
                  }}
                  label={t("settings", lang)}
                  icon={<span style={{ fontSize: 18 }}>⚙️</span>}
                  collapsed={collapsed}
                />
              </div>
            </nav>

            <div style={{ height: 8, borderRadius: 6, backgroundImage: accentGradient, opacity: 0.5 }} />
          </div>
        </div>
      </aside>

      {/* overlay when mobile nav open */}
      {isMobile && mobileNavOpen && (
        <div
          onClick={() => setMobileNavOpen(false)}
          aria-hidden
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1200,
            background: "rgba(6,30,90,0.28)",
            backdropFilter: "blur(2px)",
          }}
        />
      )}

      {/* main content area */}
      <main
        className={`${resp.main ?? ""} main`}
        style={{
          marginLeft: isMobile ? 0 : asideWidthPx,
          width: mainStyleWidth,
          minWidth: mainStyleWidth,
          transition: "margin-left 260ms cubic-bezier(.2,.9,.2,1), width 260ms ease",
          marginRight: "auto",
          boxSizing: "border-box",
          padding: 18,
        }}
      >
        <div style={{ borderRadius: 14, padding: 2, backgroundImage: primaryGradient }}>
          <div
            className="featureCard"
            style={{
              borderRadius: 12,
              padding: 20,
              minHeight: "80vh",
              boxSizing: "border-box",
              background: "var(--glass, rgba(255,255,255,0.02))",
              border: sectionBorder,
              boxShadow: cardBoxShadow,
            }}
          >
            <div className={`${resp.header ?? ""} header`} style={{ marginBottom: 18 }}>
              <h1 style={{ fontSize: 28, fontWeight: 800, margin: 0 }}>{t("dashboard", lang)}</h1>
              <p style={{ marginTop: 6, color: "var(--ink-3, rgba(230,238,248,0.7))" }}>{t("overviewQuickActions", lang)}</p>
            </div>

            <section
              className={`${resp.sectionFull ?? ""} sectionFull`}
              style={{
                borderRadius: 10,
                padding: 8,
                border: sectionBorder,
                background: "transparent",
              }}
            >
              {tab === "wallet" && (
                <div className="embeddedComponent responsiveIframeFix" style={{ border: sectionBorder, borderRadius: 8 }}>
                  <Wallet lang={lang} />
                </div>
              )}

              {tab === "activeCampaigns" && (
                <div style={{ width: "100%", boxSizing: "border-box", overflow: "visible", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
                  <div
                    style={{
                      transform: `scale(${viewScale})`,
                      transformOrigin: "top center",
                      transition: "transform 200ms ease, width 200ms ease",
                      width: `${100 / viewScale}%`,
                      boxSizing: "border-box",
                    }}
                  >
                    <ViewActiveCampaigns lang={lang} />
                  </div>
                </div>
              )}

              {tab === "brandSubmissions" && (
                <div style={{ transform: `scale(${viewScale})`, transformOrigin: "top center", transition: "transform 200ms ease, width 200ms ease", width: `${100 / viewScale}%`, boxSizing: "border-box" }}>
                  <BrandSubmissions lang={lang} />
                </div>
              )}

              {tab === "influencerSearch" && (
                <div style={{ transform: `scale(${viewScale})`, transformOrigin: "top center", transition: "transform 200ms ease, width 200ms ease", width: `${100 / viewScale}%`, boxSizing: "border-box", display: "table" }}>
                  <MTSV2 lang={lang} />
                </div>
              )}

              {tab === "campaignCreation" && (
                <div style={{ display: "content" }}>
                  <CampaignCreation lang={lang} />
                </div>
              )}

              {tab === "profile" && (
                <div style={{ transform: `scale(${viewScale})`, transformOrigin: "top center", transition: "transform 200ms ease, width 200ms ease", width: `${100 / viewScale}%`, boxSizing: "border-box", display: "table" }}>
                  <Profiles lang={lang} />
                </div>
              )}

              {tab === "home" && (
                <div style={{ width: "100%" }}>
                  {/* summary grid */}
                  <div className={`${resp.summaryGrid ?? ""} summaryGrid`} style={{ marginBottom: 16, display: "grid", gap: 12 }}>
                    <div
                      className={`previewCard featureCard ${resp.previewCard ?? ""}`}
                      style={{
                        padding: 14,
                        border: sectionBorder,
                        borderRadius: 10,
                        background: "rgba(255,255,255,0.012)",
                        boxShadow: "0 6px 20px rgba(2,6,23,0.35)",
                      }}
                    >
                      <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>{t("earnings", lang)}</h3>
                      <p style={{ marginTop: 8, fontSize: 14 }}>{dashboardLoading ? t("loading", lang) : formatCurrency(Number(earnings ?? 0))}</p>
                    </div>

                    <div
                      className={`previewCard featureCard ${resp.previewCard ?? ""}`}
                      style={{
                        padding: 14,
                        border: sectionBorder,
                        borderRadius: 10,
                        background: "rgba(255,255,255,0.012)",
                        boxShadow: "0 6px 20px rgba(2,6,23,0.35)",
                      }}
                    >
                      <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>{t("activeCampaigns", lang)}</h3>
                      <p style={{ marginTop: 8, fontSize: 14 }}>{dashboardLoading ? t("loading", lang) : `${activeCampaignsCount} ${t("running", lang)}`}</p>
                    </div>

                    <div
                      className={`previewCard featureCard ${resp.previewCard ?? ""}`}
                      style={{
                        padding: 14,
                        border: sectionBorder,
                        borderRadius: 10,
                        background: "rgba(255,255,255,0.012)",
                        boxShadow: "0 6px 20px rgba(2,6,23,0.35)",
                      }}
                    >
                      <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>{t("pendingApprovals", lang)}</h3>
                      <p style={{ marginTop: 8, fontSize: 14 }}>
                        {dashboardLoading ? t("loading", lang) : `${pendingApprovalsCount} ${pendingApprovalsCount !== 1 ? t("items", lang) : t("item", lang)}`}
                      </p>
                    </div>
                  </div>

                  {/* preview grid */}
                  <div className={`${resp.previewGrid ?? ""} previewGrid`} style={{ display: "grid", gap: 12 }}>
                    <div
                      className={`previewCard featureCard ${resp.previewCard ?? ""}`}
                      style={{
                        padding: 12,
                        border: sectionBorder,
                        borderRadius: 10,
                        background: "rgba(255,255,255,0.012)",
                        boxShadow: "0 6px 20px rgba(2,6,23,0.35)",
                      }}
                    >
                      <h4 style={{ margin: 0, fontWeight: 700 }}>{t("recentActivity", lang)}</h4>
                      <div className={`${resp.previewInnerScroll ?? ""} previewInnerScroll`} style={{ marginTop: 8, maxHeight: 220, overflowY: "auto", paddingRight: 6 }}>
                        {dashboardLoading ? (
                          <p style={{ margin: 0 }}>{t("loadingActivity", lang)}</p>
                        ) : recentActivity.length === 0 ? (
                          <p style={{ margin: 0 }}>{t("noRecentActivity", lang)}</p>
                        ) : (
                          <ul style={{ margin: 0, paddingLeft: 14 }}>
                            {recentActivity.map((a) => (
                              <li key={a.id} style={{ marginBottom: 6 }}>
                                <small style={{ color: "var(--ink-3, rgba(230,238,248,0.7))" }}>{a.text}</small>
                                <div style={{ fontSize: 12, color: "var(--ink-2, rgba(230,238,248,0.55))" }}>{new Date(a.ts).toLocaleString()}</div>
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </div>

                    <div
                      className={`previewCard featureCard ${resp.previewCard ?? ""}`}
                      style={{
                        padding: 12,
                        border: sectionBorder,
                        borderRadius: 10,
                        background: "rgba(255,255,255,0.012)",
                        boxShadow: "0 6px 20px rgba(2,6,23,0.35)",
                      }}
                    >
                      <h4 style={{ margin: 0, fontWeight: 700 }}>{t("quickActions", lang)}</h4>
                      <div className={`stackedControls`} style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 8 }}>
                        <button
                          onClick={() => {
                            setTab("campaignCreation");
                            if (isMobile) setMobileNavOpen(false);
                          }}
                          className="button-neon btn-primary"
                          style={{ padding: "8px 12px", borderRadius: 8, fontWeight: 700 }}
                        >
                          {t("createCampaign", lang)}
                        </button>

                        <button
                          onClick={() => {
                            setTab("influencerSearch");
                            if (isMobile) setMobileNavOpen(false);
                          }}
                          className="button-neon btn-secondary"
                          style={{ padding: "8px 12px", borderRadius: 8, fontWeight: 700 }}
                        >
                          {t("searchInfluencer", lang)}
                        </button>

                        <button
                          onClick={() => {
                            fetchDashboardData(userUid);
                          }}
                          className="button-neon btn-ghost"
                          style={{ padding: "8px 12px", borderRadius: 8, fontWeight: 700 }}
                        >
                          {t("refresh", lang)}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </section>
          </div>
        </div>
      </main>
    </div>
  
</div>);
}
