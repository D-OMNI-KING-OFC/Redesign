import { t } from "../i18n/index";
import { useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { UserGroupIcon, ChartBarIcon, ChatBubbleOvalLeftIcon } from "@heroicons/react/24/outline";

import { supabase } from "../lib/supabaseClient";
import VideoArch from "./VideoArch";
import MTS from "../components/MTS";


import styles from "./Landing.module.css";

type LandingProps = {
  lang: string;
};

export default function Landing({ lang }: LandingProps) {
  const navigate = useNavigate();
  const [hoveredService, setHoveredService] = useState<number | null>(null);
  const [session, setSession] = useState<any>(null);
  const [userRole, setUserRole] = useState<string | null>(null);

  // Responsive scale & collapse logic
  const MIN_SCALE = 0.3;
  const REF_WIDTH = 120;
  const [viewScale, setViewScale] = useState<number>(1);
  const resizeTimerRef = useRef<number | null>(null);
  const computeScaleFromVW = (vw: number) => Math.max(MIN_SCALE, Math.min(1, vw / REF_WIDTH));
 const [isMobile, setIsMobile] = useState<boolean>(false);

  
  useEffect(() => {
    if (typeof window === "undefined") return;
    const applyScale = () => {
      setViewScale(computeScaleFromVW(window.innerWidth));
      setIsMobile(window.innerWidth < 769);
    };
    applyScale();
    const onResize = () => {
      if (resizeTimerRef.current) window.clearTimeout(resizeTimerRef.current);
      resizeTimerRef.current = window.setTimeout(() => {
        applyScale();
        resizeTimerRef.current = null;
      }, 120) as unknown as number;
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (resizeTimerRef.current) window.clearTimeout(resizeTimerRef.current);
    };
  }, []);


  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        const { data: profile, error } = await supabase
          .from("profiles")
          .select("role")
          .eq("auth_uid", data.session.user.id)
          .single();

        if (!error && profile) setUserRole(profile.role || null);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      if (session?.user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("auth_uid", session.user.id)
          .single();
        setUserRole(profile?.role || null);
      } else {
        setUserRole(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const handleGetStarted = () => {
    if (!session) {
      navigate("/login");
    } else if (!userRole) {
      navigate("/role-selection");
    } else {
      navigate("/dashboard");
    }
  };

  const sectionsRef = useRef<Array<HTMLDivElement | null>>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.fadeIn);
          }
        });
      },
      { threshold: 0.2 }
    );

    sectionsRef.current.forEach((section) => {
      if (section) observer.observe(section);
    });

    return () => observer.disconnect();
  }, []);

  const setSectionRef = (index: number) => (el: HTMLDivElement | null) => {
    sectionsRef.current[index] = el;
  };

  const heroImageUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDfPqHycmCsGBM-gWT3WGq8dKRz2IV745MrfQug_2_4Dr2XVxGHpaEzr5syDHATBewL96d3-siYFsS_rxBSz8SABgp0xKyDxxf7qkBEXxTkm5RmJOQ9fz89dbPPT98LGRO_47p0vu34ee0-hkJTz-cAN2BFAiHw6DrUjeoRHO7zxcL9rCUjTcO-01zHMBPX0VdbpTLVG2R-lRWTYlZ9KwDdah5JBfZLW42tS69Eub6NeniMD_114PcU3KQypBSOL2R5l1haqAe0rYQ";

  const featureImage1 = "https://lh3.googleusercontent.com/aida-public/AB6AXuDTAkrc1Jz5yicifSte8KMC5xRRPkp5vsonuzdbxn9BRq6L-421rZAMeROSf0Oe7mBRMnXkJ3Y5EYTyYD9xJpjOdKuePCbgNXEQT6V426Zq0Yk9b7Udyvtua_G2X45A1V6Em0hlI_7Xy0XyHfVDcQ5PjPmGEfEUb0clCHsmYSx2ik8FdJIbAVJm55PIbEaFwYnKxotyeE4TF4g3xiZUYm-BbJVgNcMiMe3xFzQ8a-S0zvC4Dga_VQjUmi_HHjO2a2h9ZTJNoZaKd8Q";
  const featureImage2 = "https://lh3.googleusercontent.com/aida-public/AB6AXuCHZoc_yX_U05bLpstdvy6mwCvANdCZQ1UUUgXC4LHhwyGV4AKpcfC5_a7iLdCPvkxkgiP2FxKpo9PapQCaoRiG6LYlQdgtTUJ-0sySiSzERdH7T1VqQckceH2Oos27MIz4b7CWATnShui76a-5OMAWTRH7WKUV9fogzzAc5a-crMcJwDIT_OIugt1V2zrxSCiXkTheRD_msdfoTFOZAloUMPYlaxoDo2733k-sH7OIjaAg3OSwWnC14i4uElIrZTrQSh0RrlLGpEE";
  const featureImage3 = "https://lh3.googleusercontent.com/aida-public/AB6AXuC1cfOUmG9i7WqkvTR7zByXOtqUpeZxkOVt08XwUohzNiazix0xXT5_VI6ACVKtlsXLSTdgE4QnBnWzpaObWCnwA8Qmsg8Xwq033itODM6KnAqv7MpVEIsIRGUCOwBSZRihGh-ZZGE0wzMJIQyA2aYiuWTnLHTs_2zGqw0paXTnwds3zxfs03anGcYrXzl5A26c0DwlKmArrSPjD2xgFjplsHZ3pOnAFWEVuyVI-KdxRXC0KX3tCYJiOfPSL0hCvKxATdYQETrWHJE";

  return (
    <div className={styles.landingContainer}>
      <header className={styles.header}>
        <div className={styles.logoContainer}>
          <div className={styles.logoIcon} aria-hidden>
            <img src="src/assets/cc-3d.png" alt="" style={{maxHeight:"110%", maxWidth:"110%", borderRadius:"50%"  }}  />
          </div>
          <h2 className={styles.logoText ?? ""}>CollabConnect</h2>
        </div>

        <nav className={styles.navLinks}>
          <a className={styles.navLink} href="#home">{t("landingNavHome", lang) || "Home"}</a>
          <a className={styles.navLink} href="#features">{t("landingNavFeatures", lang) || "Features"}</a>
          <a className={styles.navLink} href="#pricing">{t("landingNavPricing", lang) || "Pricing"}</a>
          <a className={styles.navLink} href="#resources">{t("landingNavResources", lang) || "Resources"}</a>
        </nav>

        <div className={styles.mh}>
          <button className={`${styles.headerButton} ${styles.loginButton}`} onClick={() => navigate("/login")} type="button">
            <span className="truncate">{t("signIn", lang)}</span>
          </button>

          <button className={`${styles.headerButton} ${styles.getStartedButton}`} onClick={handleGetStarted} type="button">
            <span className="truncate">{t("getStarted", lang)}</span>
          </button>
        </div>
      </header>

      <main>
        <section ref={setSectionRef(0)} className={`${styles.heroSection} ${styles.section}`}>
          <div className={styles.heroOverlay} aria-hidden />
          <div className={styles.heroBg} >
            <div className={styles.heroContent}>
              <h1 className={styles.heroTitle}>{t("landingTitle", lang)}</h1>
              <p className={styles.heroSubtitle}>{t("landingSubtitle", lang)}</p>
              <div className={styles.heroButtons}>
                <button className={`${styles.heroButton} ${styles.heroButtonPrimary}`} onClick={handleGetStarted}>
                  <span className="truncate">{t("getStarted", lang)}</span>
                </button>
                <button className={`${styles.heroButton} ${styles.heroButtonSecondary}`} onClick={() => {
                    const el = document.getElementById("features");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }}>
                  <span className="truncate">{t("landingLearnMore", lang)}</span>
                </button>
              </div>
            </div>
          </div>
        </section>


        <section>
           <div
                    style={{
                      transform: `scale(${viewScale})`,
                      transformOrigin: "top center",
                      transition: "transform 200ms ease, width 200ms ease",
                    width:"100%",
                      boxSizing: "border-box",
                    }}
                  >
            <div style={{   padding:"25px",  maxWidth:"100%", maxHeight:"500px" , display:"flex", flexDirection:"column", justifyContent:"center", justifyItems:"center", alignItems:"center", alignContent:"center" }} >     
          <VideoArch  />
</div>
          </div>
        </section>

        <section style={{ display: "flex", justifyContent: "center", flexDirection:"column" , padding: "2rem" , alignContent:"space-between"}}>
          <MTS lang={lang} />
        </section>

        <section id="features" ref={setSectionRef(1)} className={`${styles.featuresSection} ${styles.section}`}>
          <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 1rem" }}>
            <div style={{ textAlign: "center", maxWidth: 800, margin: "0 auto 3rem" }}>
              <h2 className={styles.heroTitle}>{t("servicesTitle", lang)}</h2>
              <h3 className={styles.heroTitle}>{t("service1Title", lang)}</h3>
              <p className={styles.heroSubtitle}>{t("serviceDesc", lang)}</p>
              <p className={styles.heroSubTitle}>{t("service1Brag", lang)}</p>
            </div>

            <div className={styles.featuresContainer}>
              <div className={styles.featureCard}>
                <div className={styles.featureImage} style={{ backgroundImage: `url("${featureImage1}")` }}/>
                <div>
                  <h3 className={styles.featureTitle}>{t("feature1Title", lang)}</h3>
                  <p className={styles.featureDesc}>{t("feature1Desc", lang)}</p>
                </div>
              </div>

              <div className={styles.featureCard}>
                <div className={styles.featureImage} style={{ backgroundImage: `url("${featureImage2}")` }}/>
                <div>
                  <h3 className={styles.featureTitle}>{t("feature2Title", lang)}</h3>
                  <p className={styles.featureDesc}>{t("feature2Desc", lang)}</p>
                </div>
              </div>

              <div className={styles.featureCard}>
                <div className={styles.featureImage} style={{ backgroundImage: `url("${featureImage3}")` }}/>
                <div>
                  <h3 className={styles.featureTitle}>{t("feature3Title", lang)}</h3>
                  <p className={styles.featureDesc}>{t("feature3Desc", lang)}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section ref={setSectionRef(2)} className={`${styles.featuresSection} ${styles.section}`}>
          <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 1rem", textAlign: "center" }}>
            <h2 className={styles.heroTitle}>{t("whyUsTitle", lang)}</h2>
            <div style={{ display: "flex", justifyContent: "center", gap: 32, flexWrap: "wrap", marginTop: 24 }}>
              <div style={{ maxWidth: 220, padding: 16 }}>
                <h3 style={{ fontSize: 28, color: "var(--primary)", margin: 0 }}>{t("stat1Number", lang)}</h3>
                <p style={{ marginTop: 8 }}>{t("stat1Text", lang)}</p>
              </div>
              <div style={{ maxWidth: 220, padding: 16 }}>
                <h3 style={{ fontSize: 28, color: "var(--primary)", margin: 0 }}>{t("stat2Number", lang)}</h3>
                <p style={{ marginTop: 8 }}>{t("stat2Text", lang)}</p>
              </div>
              <div style={{ maxWidth: 220, padding: 16 }}>
                <h3 style={{ fontSize: 28, color: "var(--primary)", margin: 0 }}>{t("stat3Number", lang)}</h3>
                <p style={{ marginTop: 8 }}>{t("stat3Text", lang)}</p>
              </div>
            </div>
          </div>
        </section>

        <section ref={setSectionRef(3)} className={`${styles.ctaSection} ${styles.section}`}>
          <div style={{ maxWidth: 800, margin: "0 auto", padding: "0 1rem", textAlign: "center" }}>
            <h2 className={styles.heroTitle}>{t("ctaTitle", lang)}</h2>
            <div style={{ marginTop: 24 , textAlign:"center", maxWidth:"800" }}>
              <button className={styles.ctaButton} onClick={handleGetStarted}>
                <span className="truncate">{t("getStarted", lang)}</span>
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className={styles.footer}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 1rem" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
            <div className={styles.footerLinks}>
              <a className={styles.footerLink} href="#terms">{t("landingTerms", lang)}</a>
              <a className={styles.footerLink} href="#privacy">{t("landingPrivacy", lang)}</a>
              <a className={styles.footerLink} href="#contact">{t("landingContact", lang)}</a>
            </div>
            <p className={styles.footerText}>© 2025 CollabConnect. {t("footerText", lang)}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
