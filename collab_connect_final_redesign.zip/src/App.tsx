import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import Landing from "./pages/Landing"
import Login from "./components/Auth"
import RoleSelection from "./pages/RoleSelection"
import Dashboard from "./components/Dashboard"
import BrandDashboard from "./components/BrandDashboard"
import InfluencerDashboard from "./components/InfluencerDashboard"
import { useState, useEffect } from "react"

import { supabase } from "./lib/supabaseClient"

import LoadingScreen from "./components/LoadingScreen"

import Translate from "./components/Translate"
import  Landing_Fusion    from "./pages/Landing_Fusion"
import BuilderPage from './BuilderPage';

export default function App() {
  const [session, setSession] = useState<any>(null)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [lang, setLang] = useState<"en" | "ko" | "fr">("en");

  useEffect(() => {
    const fetchSession = async () => {
      const { data } = await supabase.auth.getSession()
      setSession(data.session)

      if (data.session?.user) {
        const { data: profile, error } = await supabase
          .from("profiles")
          .select("role")
          .eq("auth_uid", data.session.user.id)
          .single()
        if (!error && profile) setUserRole(profile.role || null)
      }
      setLoading(false)
    }

    fetchSession()

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      if (session?.user) {
        supabase
          .from("profiles")
          .select("role")
          .eq("auth_uid", session.user.id)
          .single()
          .then(({ data: profile }) => setUserRole(profile?.role || null))
      } else {
        setUserRole(null)
      }
    })

    return () => listener.subscription.unsubscribe()
  }, [])

  if (loading) return <div> < LoadingScreen/> </div>

  return (
  <>
    <Translate lang={lang} setLang={setLang} />

    <Router>
      <Routes>
        {/* Landing */}
        <Route path="/" element={<Landing lang={lang} />} />

        {/* Login */}
        {!session ? (
          <Route path="/login" element={<Login lang={lang} />} />
        ) : (
          <>
            {/* Role selection */}
            <Route
              path="/role-selection"
              element={<RoleSelection lang={lang} session={session} userID={""} />}
            />

            {/* Main dashboard fallback */}
            <Route path="/dashboard" element={<Dashboard lang={lang} session={session} />} />

            {/* Separate role dashboards */}
            {userRole === "brand" && (
              <Route
                path="/brand-dashboard"
                element={<BrandDashboard lang={lang} session={session} />}
              />
            )}
            {userRole === "influencer" && (
              <Route
                path="/influencer-dashboard"
                element={<InfluencerDashboard lang={lang} session={session} />}
              />
            )}
            <Route path="/builder/*" element={<BuilderPage />} />

            {/* Redirect /login to /dashboard if already logged in */}
            <Route path="/login" element={<Navigate to="/dashboard" replace />} />
          </>
        )}

        {/* Catch-all redirect to landing */}
        <Route path="*" element={<Navigate to="/" replace />} />

      </Routes>
    </Router>
     </>
  )
}
